obs = obslua
local cfg=nil
local scene_name='KMG Stream Layout'
local panel_signal_source=nil
local browser_css='body { background: transparent; margin: 0; overflow: hidden; }'
local boxes={game={32,32,1384,778},custom1={32,842,440,206},custom2={504,842,440,206},custom3={976,842,440,206},chat={1448,32,440,317},translation={1448,381,440,317},hand={1448,730,440,318}}
local areas={{'chatUrl','KMG · Chat','chat','showChat'},
 {'translationUrl','KMG · Translation','translation','showSubtitles'},
 {'donationChzzk','KMG · CHZZK Alerts','alerts','showAlerts'},
 {'donationTwitch','KMG · Twitch Alerts','alerts','showAlerts'},
 {'donationYoutube','KMG · YouTube Alerts','alerts','showAlerts'},
 {'donationSoop','KMG · SOOP Alerts','alerts','showAlerts'},
 {'reactiveUrl','KMG · Discord Reactive','hand','reactive'}}
function script_description()
 return 'KMG Stream Layout: preview.html → Save OBS settings ZIP → Extract into this folder → Apply. Links are read from obs-settings.json. Existing scenes and capture settings are preserved. External widget styling is controlled by its provider.'
end
function script_update(settings)
 if cfg~=nil then obs.obs_data_release(cfg) end
 cfg=settings;obs.obs_data_addref(cfg)
end
local function panel_backdrop(visible)
 local source=obs.obs_get_source_by_name('KMG · Panel Fill')
 if source==nil then return end
 local data=obs.obs_source_get_settings(source)
 obs.obs_data_set_string(data,'css',browser_css..(visible and '' or '.backdrop{display:none!important;}'))
 obs.obs_source_update(source,data)
 obs.obs_data_release(data);obs.obs_source_release(source)
end
local function sync_panel_fill(calldata)
 local item=obs.calldata_sceneitem(calldata,'item')
 if item==nil then return end
 local name=obs.obs_source_get_name(obs.obs_sceneitem_get_source(item))
 if name=='KMG · Background' then panel_backdrop(obs.obs_sceneitem_visible(item));return end
 if name~='KMG · Panel Stroke' then return end
 local source=obs.obs_get_source_by_name(scene_name)
 if source==nil then return end
 local scene=obs.obs_scene_from_source(source)
 local fill=scene~=nil and obs.obs_scene_find_source(scene,'KMG · Panel Fill') or nil
 if fill~=nil then obs.obs_sceneitem_set_visible(fill,obs.obs_sceneitem_visible(item)) end
 obs.obs_source_release(source)
end
local function connect_panel_signal()
 if panel_signal_source~=nil then
  obs.signal_handler_disconnect(obs.obs_source_get_signal_handler(panel_signal_source),'item_visible',sync_panel_fill)
  obs.obs_source_release(panel_signal_source)
 end
 panel_signal_source=obs.obs_get_source_by_name(scene_name)
 if panel_signal_source~=nil then obs.signal_handler_connect(obs.obs_source_get_signal_handler(panel_signal_source),'item_visible',sync_panel_fill) end
end
function script_unload()
 if panel_signal_source~=nil then
  obs.signal_handler_disconnect(obs.obs_source_get_signal_handler(panel_signal_source),'item_visible',sync_panel_fill)
  obs.obs_source_release(panel_signal_source);panel_signal_source=nil
 end
 if cfg~=nil then obs.obs_data_release(cfg);cfg=nil end
end
local function place(scene,source,x,y,w,h,bottom)
 local item=obs.obs_scene_find_source(scene,obs.obs_source_get_name(source))
 if item==nil then item=obs.obs_scene_add(scene,source) end
 local pos=obs.vec2();pos.x=x;pos.y=y
 local bounds=obs.vec2();bounds.x=w;bounds.y=h
 obs.obs_sceneitem_set_alignment(item,5)
 obs.obs_sceneitem_set_pos(item,pos)
 obs.obs_sceneitem_set_bounds_type(item,obs.OBS_BOUNDS_SCALE_INNER)
 obs.obs_sceneitem_set_bounds_alignment(item,0)
 obs.obs_sceneitem_set_bounds(item,bounds)
 obs.obs_sceneitem_set_order(item,bottom and obs.OBS_ORDER_MOVE_BOTTOM or obs.OBS_ORDER_MOVE_TOP)
 obs.obs_sceneitem_set_visible(item,true)
end
local function remove(scene,name)
 local item=obs.obs_scene_find_source(scene,name)
 if item~=nil then obs.obs_sceneitem_remove(item) end
end
local function browser(scene,name,url,file,x,y,w,h,css,bottom)
 local data=obs.obs_data_create()
 obs.obs_data_set_int(data,'width',w);obs.obs_data_set_int(data,'height',h)
 obs.obs_data_set_string(data,'css',css or browser_css)
 obs.obs_data_set_bool(data,'is_local_file',file)
 obs.obs_data_set_string(data,file and 'local_file' or 'url',url)
 local source=obs.obs_get_source_by_name(name)
 if source==nil then source=obs.obs_source_create('browser_source',name,data,nil)
 else
  obs.obs_source_update(source,data)
  if file then
   local properties=obs.obs_source_properties(source)
   if properties~=nil then
    local refresh=obs.obs_properties_get(properties,'refreshnocache')
    if refresh~=nil then obs.obs_property_button_clicked(refresh,source) end
    obs.obs_properties_destroy(properties)
   end
  end
 end
 if source~=nil then place(scene,source,x,y,w,h,bottom);obs.obs_source_release(source) end
 obs.obs_data_release(data)
end
local function clip(scene,name,selected,mask_path,box,url)
 if selected=='' then remove(scene,name);return true end
 local mask=io.open(mask_path,'rb')
 if mask==nil then return false end
 mask:close()
 local clip_source=obs.obs_get_source_by_name(name)
 local nested,created
 created=clip_source==nil
 if created then nested=obs.obs_scene_create(name);clip_source=obs.obs_scene_get_source(nested)
 else nested=obs.obs_scene_from_source(clip_source) end
 if nested==nil then if clip_source~=nil and not created then obs.obs_source_release(clip_source) end;return false end
 local items=obs.obs_scene_enum_items(nested)
 if items~=nil then
  for _,item in ipairs(items) do if obs.obs_source_get_name(obs.obs_sceneitem_get_source(item))~=selected then obs.obs_sceneitem_remove(item) end end
  obs.sceneitem_list_release(items)
 end
 if url~=nil then browser(nested,selected,url,false,unpack(box))
 else
  local capture=obs.obs_get_source_by_name(selected)
  if capture~=nil then place(nested,capture,unpack(box));obs.obs_source_release(capture) end
 end
 local data=obs.obs_data_create()
 obs.obs_data_set_string(data,'type','mask_alpha_filter.effect')
 obs.obs_data_set_string(data,'image_path',mask_path)
 obs.obs_data_set_int(data,'opacity',100)
 obs.obs_data_set_bool(data,'stretch',true)
 local filter=obs.obs_source_get_filter_by_name(clip_source,'KMG · Alpha Mask')
 if filter==nil then filter=obs.obs_source_create('mask_filter','KMG · Alpha Mask',data,nil);if filter~=nil then obs.obs_source_filter_add(clip_source,filter) end
 else obs.obs_source_update(filter,data) end
 obs.obs_data_release(data)
 local ok=filter~=nil
 if filter~=nil then obs.obs_source_release(filter) end
 if ok then place(scene,clip_source,0,0,1920,1080) else remove(scene,name) end
 if created then obs.obs_scene_release(nested) else obs.obs_source_release(clip_source) end
 return ok
end
local function apply(props,property)
 local file=io.open(script_path()..'obs-settings.json','r')
 if file==nil then obs.script_log(obs.LOG_WARNING,'Save the OBS settings ZIP in preview.html and extract it into the overlay folder first.');return false end
 local json=file:read('*a');file:close()
 local settings=obs.obs_data_create_from_json(json)
 if settings==nil then obs.script_log(obs.LOG_WARNING,'Invalid obs-settings.json. Export settings again.');return false end
 local mode=obs.obs_data_get_string(settings,'cameraMode')
 if mode=='' then mode=obs.obs_data_get_bool(settings,'handcam') and 'camera' or 'none' end
 if mode~='camera' and mode~='reactive' and mode~='none' then obs.script_log(obs.LOG_WARNING,'Invalid camera mode.');obs.obs_data_release(settings);return false end
 local layout_version=obs.obs_data_get_int(settings,'layoutVersion')
 local slots={custom1='sponsor',custom2='alerts',custom3='none'}
 local saved_slots=obs.obs_data_get_obj(settings,'slotContent')
 if saved_slots~=nil and (layout_version==2 or layout_version==3) then
  local used={}
  for _,slot in ipairs({'custom1','custom2','custom3'}) do
   local role=obs.obs_data_get_string(saved_slots,slot)
   if not ({sponsor=true,alerts=true,image=true,video=true,browser=true,source=true,none=true})[role] or ((role=='sponsor' or role=='alerts') and used[role]) then
    obs.script_log(obs.LOG_WARNING,'Invalid small region content.');obs.obs_data_release(saved_slots);obs.obs_data_release(settings);return false
   end
   used[role]=true;slots[slot]=role
  end
 end
 if saved_slots~=nil then obs.obs_data_release(saved_slots) end
 local role_slot={}
 for slot,role in pairs(slots) do if role~='none' then role_slot[role]=slot end end
 local positions={}
 local layout=obs.obs_data_get_obj(settings,'layout')
 for key,box in pairs(boxes) do
  local x,y,w,h=box[1],box[2],box[3],box[4]
  local position=layout~=nil and (layout_version==2 or layout_version==3) and obs.obs_data_get_obj(layout,key) or nil
  if layout_version==3 and position==nil then
   obs.script_log(obs.LOG_WARNING,'Missing auto layout region: '..key)
   if layout~=nil then obs.obs_data_release(layout) end
   obs.obs_data_release(settings);return false
  end
  if position~=nil then
   x=obs.obs_data_get_double(position,'x');y=obs.obs_data_get_double(position,'y')
   local valid=obs.obs_data_has_user_value(position,'x') and obs.obs_data_has_user_value(position,'y')
   if layout_version==3 then
    w=obs.obs_data_get_double(position,'width');h=obs.obs_data_get_double(position,'height')
    valid=valid and obs.obs_data_has_user_value(position,'width') and obs.obs_data_has_user_value(position,'height')
   end
   obs.obs_data_release(position)
   if not valid or x~=math.floor(x) or y~=math.floor(y) or w~=math.floor(w) or h~=math.floor(h) or x<0 or y<0 or w<=0 or h<=0 or x+w>1920 or y+h>1080 then
    obs.script_log(obs.LOG_WARNING,'Invalid region position: '..key);obs.obs_data_release(layout);obs.obs_data_release(settings);return false
   end
  end
  positions[key]={x,y,w,h}
 end
 if layout~=nil then obs.obs_data_release(layout) end
 for _,a in ipairs(areas) do
  local url=obs.obs_data_get_string(settings,a[1])
  if url~='' and (not url:lower():match('^https?://[^/%s]+') or url:match('^https?://[^/]*@')) then
   obs.script_log(obs.LOG_WARNING,'HTTP(S) widget URL required: '..a[1]);obs.obs_data_release(settings);return false
  end
 end
 local custom_urls={}
 local media=obs.obs_data_get_obj(settings,'customSlotMedia')
 for _,slot in ipairs({'custom1','custom2','custom3'}) do
  if slots[slot]=='browser' then
   local item=media~=nil and obs.obs_data_get_obj(media,slot) or nil
   local url=item~=nil and obs.obs_data_get_string(item,'url') or ''
   if item~=nil then obs.obs_data_release(item) end
   if not url:lower():match('^https?://[^/%s]+') or url:match('^https?://[^/]*@') then
    obs.script_log(obs.LOG_WARNING,'HTTP(S) browser URL required: '..slot)
    if media~=nil then obs.obs_data_release(media) end
    obs.obs_data_release(settings);return false
   end
   custom_urls[slot]=url
  end
 end
 if media~=nil then obs.obs_data_release(media) end
 if mode=='reactive' and obs.obs_data_get_string(settings,'reactiveUrl')=='' then obs.script_log(obs.LOG_WARNING,'Discord Reactive OBS URL required.');obs.obs_data_release(settings);return false end
 local html=io.open(script_path()..'overlay.html','r')
 if html==nil then obs.script_log(obs.LOG_WARNING,'Keep the script and overlay.html in the same folder.');obs.obs_data_release(settings);return false end
 html:close()
 local background=io.open(script_path()..'background.html','r')
 if background==nil then obs.script_log(obs.LOG_WARNING,'Keep background.html in the overlay folder.');obs.obs_data_release(settings);return false end
 background:close()
 local frame=io.open(script_path()..'frame.html','r')
 if frame==nil then obs.script_log(obs.LOG_WARNING,'Keep frame.html in the overlay folder.');obs.obs_data_release(settings);return false end
 frame:close()
 local wallpaper=io.open(script_path()..'wallpaper.html','r')
 if wallpaper==nil then obs.script_log(obs.LOG_WARNING,'Keep wallpaper.html in the overlay folder.');obs.obs_data_release(settings);return false end
 wallpaper:close()
 local game=obs.obs_data_get_string(cfg,'game')
 local camera=obs.obs_data_get_string(cfg,'hand')
 if game~='' and game==camera and mode=='camera' then
  obs.script_log(obs.LOG_WARNING,'Select separate game and camera sources.');obs.obs_data_release(settings);return false
 end
 for _,slot in ipairs({'custom1','custom2','custom3'}) do
  if slots[slot]=='source' then
   local name=obs.obs_data_get_string(cfg,slot..'Source')
   if name~='' then
    local item=obs.obs_get_source_by_name(name)
    if item==nil or obs.obs_scene_from_source(item)~=nil or name:match('^KMG · ') then
     if item~=nil then obs.obs_source_release(item) end
     obs.script_log(obs.LOG_WARNING,'Select an existing non-KMG OBS source for '..slot)
     obs.obs_data_release(settings);return false
    end
    obs.obs_source_release(item)
   end
  end
 end
 local masked={{'game',game},{'camera',mode=='camera' and camera or ''}}
 for _,slot in ipairs({'custom1','custom2','custom3'}) do
  local selected=slots[slot]=='browser' and 'browser' or slots[slot]=='source' and obs.obs_data_get_string(cfg,slot..'Source') or ''
  masked[#masked+1]={slot,selected}
 end
 for _,entry in ipairs(masked) do
  if entry[2]~='' then
   if entry[1]=='game' or entry[1]=='camera' then
    local selected=obs.obs_get_source_by_name(entry[2])
    if selected==nil or obs.obs_scene_from_source(selected)~=nil then
     if selected~=nil then obs.obs_source_release(selected) end
     obs.script_log(obs.LOG_WARNING,'Select an existing '..entry[1]..' source.');obs.obs_data_release(settings);return false
    end
    obs.obs_source_release(selected)
   end
   local mask=io.open(script_path()..'assets/'..entry[1]..'-alpha-mask.png','rb')
   if mask==nil then obs.script_log(obs.LOG_WARNING,'Export and extract a fresh settings ZIP to create the rounded '..entry[1]..' mask.');obs.obs_data_release(settings);return false end
   mask:close()
  end
 end
 local source=obs.obs_get_source_by_name(scene_name)
 local scene,created
 created=source==nil
 if created then scene=obs.obs_scene_create(scene_name);source=obs.obs_scene_get_source(scene)
 else scene=obs.obs_scene_from_source(source) end
 if scene==nil then obs.obs_source_release(source);obs.obs_data_release(settings);return false end
 local panel_settings=obs.obs_data_get_obj(settings,'panelEnabled')
 local function panel_enabled(key)
  return key~=nil and (panel_settings==nil or not obs.obs_data_has_user_value(panel_settings,key) or obs.obs_data_get_bool(panel_settings,key))
 end
 local function release_panel_settings()
  if panel_settings~=nil then obs.obs_data_release(panel_settings);panel_settings=nil end
 end
 local existing_panels=obs.obs_scene_find_source(scene,'KMG · Panel Stroke') or obs.obs_scene_find_source(scene,'KMG · Panels')
 local panels_visible=existing_panels==nil or obs.obs_sceneitem_visible(existing_panels)
 local existing_background=obs.obs_scene_find_source(scene,'KMG · Background')
 local background_visible=existing_background==nil or obs.obs_sceneitem_visible(existing_background)
 local css='body { background: transparent; margin: 0; overflow: hidden; }'
 local feeds={chatUrl='#chat-feed',translationUrl='#subtitles'}
 for key,selector in pairs(feeds) do
  if obs.obs_data_get_string(settings,key)~='' then css=css..selector..'{display:none!important;}' end
 end
 local has_alerts=false
 for _,a in ipairs(areas) do
  if a[4]=='showAlerts' and obs.obs_data_get_string(settings,a[1])~='' then has_alerts=true end
 end
 if has_alerts then css=css..'#alert-default,#alert-active{display:none!important;}' end
 -- Remove the old owned demo, never unrelated sources.
 local items=obs.obs_scene_enum_items(scene)
 if items~=nil then
  for _,item in ipairs(items) do
   local s=obs.obs_sceneitem_get_source(item)
   local data=obs.obs_source_get_settings(s)
   if obs.obs_data_get_string(data,'local_file')==script_path()..'demo.html' then obs.obs_sceneitem_remove(item) end
   obs.obs_data_release(data)
  end
  obs.sceneitem_list_release(items)
 end
 -- Replace old script sources in this scene when migrating.
 for _,name in ipairs({'KMG · Donation','KMG · Sponsor'}) do remove(scene,name) end
 -- The alpha mask is applied to KMG-owned nested scenes, not shared capture sources.
 remove(scene,'KMG · Game Mask');remove(scene,'KMG · Camera Mask')
 if panel_enabled('game') then
  if not clip(scene,'KMG · Game Clip',game,script_path()..'assets/game-alpha-mask.png',positions.game) then obs.script_log(obs.LOG_WARNING,'Game mask filter unavailable.');release_panel_settings();obs.obs_data_release(settings);return false end
 else remove(scene,'KMG · Game Clip') end
 if panel_enabled('hand') and mode=='camera' and camera~='' then
  if not clip(scene,'KMG · Camera Clip',camera,script_path()..'assets/camera-alpha-mask.png',positions.hand) then obs.script_log(obs.LOG_WARNING,'Camera mask filter unavailable.');release_panel_settings();obs.obs_data_release(settings);return false end
 else remove(scene,'KMG · Camera Clip') end
 for _,key in ipairs({'game','hand'}) do
  local previous=obs.obs_data_get_string(cfg,'placed_'..key)
  local selected=obs.obs_data_get_string(cfg,key)
  if previous~='' then remove(scene,previous) end
  if selected~='' then remove(scene,selected) end
  obs.obs_data_set_string(cfg,'placed_'..key,selected)
 end
 for _,a in ipairs(areas) do
  local url=obs.obs_data_get_string(settings,a[1])
  local slot=a[3]
  if slot=='alerts' then slot=role_slot.alerts elseif slot=='hand' then slot=mode=='reactive' and 'hand' or nil end
  local enabled=panel_enabled(slot) and (a[4]=='reactive' or obs.obs_data_get_bool(settings,a[4]))
  local box=slot and positions[slot] or nil
  if url~='' and enabled then browser(scene,a[2],url,false,box[1],box[2],box[3],box[4]) else remove(scene,a[2]) end
 end
 for i,slot in ipairs({'custom1','custom2','custom3'}) do
  local browser_name='KMG · Custom '..i
  local clip_name=browser_name..' Clip'
  local mask=script_path()..'assets/'..slot..'-alpha-mask.png'
  local box=positions[slot]
  remove(scene,browser_name)
  if not panel_enabled(slot) then remove(scene,clip_name)
  elseif slots[slot]=='browser' then
   if not clip(scene,clip_name,browser_name,mask,box,custom_urls[slot]) then obs.script_log(obs.LOG_WARNING,'Custom browser mask unavailable: '..slot);release_panel_settings();obs.obs_data_release(settings);return false end
  elseif slots[slot]=='source' then
   local name=obs.obs_data_get_string(cfg,slot..'Source')
   if not clip(scene,clip_name,name,mask,box) then obs.script_log(obs.LOG_WARNING,'Custom source mask unavailable: '..slot);release_panel_settings();obs.obs_data_release(settings);return false end
  else remove(scene,clip_name) end
  obs.obs_data_set_string(cfg,'placed_'..slot,'')
 end
 browser(scene,'KMG · Panel Fill',script_path()..'background.html',true,0,0,1920,1080,nil,true)
 browser(scene,'KMG · Background',script_path()..'wallpaper.html',true,0,0,1920,1080,nil,true)
 browser(scene,'KMG · Overlay',script_path()..'overlay.html',true,0,0,1920,1080,css)
 remove(scene,'KMG · Panels')
 browser(scene,'KMG · Panel Stroke',script_path()..'frame.html',true,0,0,1920,1080)
 obs.obs_sceneitem_set_visible(obs.obs_scene_find_source(scene,'KMG · Panel Stroke'),panels_visible)
 obs.obs_sceneitem_set_visible(obs.obs_scene_find_source(scene,'KMG · Panel Fill'),panels_visible)
 obs.obs_sceneitem_set_visible(obs.obs_scene_find_source(scene,'KMG · Background'),background_visible)
 panel_backdrop(background_visible)
 connect_panel_signal()
 obs.obs_frontend_set_current_scene(source)
 if created then obs.obs_scene_release(scene) else obs.obs_source_release(source) end
 obs.obs_data_release(settings)
 release_panel_settings()
 obs.script_log(obs.LOG_INFO,'KMG Stream Layout applied. Base canvas must be 1920 x 1080. No links are logged.')
 return true
end
function script_properties()
 local p=obs.obs_properties_create()
 local en=cfg~=nil and obs.obs_data_get_bool(cfg,'english')
 obs.obs_properties_add_bool(p,'english','English UI (reload after changing)')
 local labels={game=en and 'Existing game source' or '기존 게임 소스',hand=en and 'Existing camera source' or '기존 캠 소스',custom1Source=en and 'Custom 1 OBS source' or '커스텀 1 OBS 소스',custom2Source=en and 'Custom 2 OBS source' or '커스텀 2 OBS 소스',custom3Source=en and 'Custom 3 OBS source' or '커스텀 3 OBS 소스'}
 for _,key in ipairs({'game','hand','custom1Source','custom2Source','custom3Source'}) do
  local list=obs.obs_properties_add_list(p,key,labels[key],obs.OBS_COMBO_TYPE_LIST,obs.OBS_COMBO_FORMAT_STRING)
  obs.obs_property_list_add_string(list,en and 'None' or '사용 안 함','')
  local sources=obs.obs_enum_sources()
  if sources~=nil then
   for _,s in ipairs(sources) do
    if obs.obs_scene_from_source(s)==nil then local name=obs.obs_source_get_name(s);if not name:match('^KMG · ') then obs.obs_property_list_add_string(list,name,name) end end
   end
   obs.source_list_release(sources)
  end
 end
 obs.obs_properties_add_button(p,'apply',en and 'Apply saved settings / Auto layout' or '저장한 설정 / 자동 배치 적용',apply)
 return p
end
