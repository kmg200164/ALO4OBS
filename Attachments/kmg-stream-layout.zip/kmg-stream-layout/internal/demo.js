(() => {
 const now=Date.now();
 Overlay.applyConfig({...window.OVERLAY_CONFIG,name:'YANGDOUN',logo:'assets/demo-player.svg',sponsor:'assets/team-tgm25.jpg',sponsorType:'image',showNicknames:true,slotContent:{custom1:'sponsor',custom2:'image',custom3:'image'},customSlotMedia:{custom2:{url:'assets/tgm26-qualified-banner.png'},custom3:{url:'assets/sample-mission-widget.png'}},regionBackgrounds:{custom3:{borderVisible:false}}});
 const chats=[['chzzk','한국팬','오늘도 응원합니다!'],['twitch','OverseasFan','That was a clean play!'],['youtube','GameWatcher','What sensitivity do you use?'],['soop','숲시청자','캠도 보기 좋네요'],['chzzk','시청자','다음 라운드도 가보자']];
 const subtitles=["I heard footsteps on the left. Let's rotate back.","Hold this angle. I'll cover our teammate."];
 chats.forEach(([platform,nickname,text],i)=>Overlay.receive({type:'chat',platform,nickname,text,id:'demo-'+i,timestamp:now-(chats.length-i)*2000}));
 subtitles.forEach((text,i)=>Overlay.receive({type:'subtitle',platform:'external',text,timestamp:now-(subtitles.length-i)*5000}));
 // Demonstration only: no accounts, microphone or API connection.
})();
