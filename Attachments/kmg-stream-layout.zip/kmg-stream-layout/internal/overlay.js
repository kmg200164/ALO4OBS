(() => {
  const $ = id => document.getElementById(id);
  const panel = key => document.querySelector(`.overlay section[data-region="${key}"]`);
  const canvas = document.querySelector('.overlay');
  const defaults = {...(document.body.classList.contains('preview-mode')?window.OVERLAY_PUBLIC_CONFIG:window.OVERLAY_CONFIG)};
  const fallbackLogo = 'assets/neutral-logo.svg';
  let config = {...defaults}, history = [], timer = null, queue = [];
  const store = OverlayEvents.createEventStore(100);
  const labels = {chzzk:'CHZZK',twitch:'TWITCH',youtube:'YOUTUBE',soop:'SOOP',external:'LIVE'};
  function scale() {canvas.style.transform = `scale(${Math.min(innerWidth/1920,innerHeight/1080)})`;}
  addEventListener('resize',scale); scale();
  const safeHttp = value => {try{const url=new URL(value);return ['http:','https:'].includes(url.protocol)&&!url.username&&!url.password?value:'';}catch{return '';}};
  const safePath = value => typeof value==='string' && (/^assets\/(?!.*\.\.)[\w./-]+$/i.test(value)||/^data:(image\/(png|jpeg|webp|gif)|video\/(mp4|webm));base64,/i.test(value)||safeHttp(value)) ? value : '';
  let sponsorMediaKey = '';
  const customMediaKeys = {};
  function media() {
    const image = $('sponsor-image'), video = $('sponsor-video'), embed=$('sponsor-embed'), path = safePath(config.sponsor);
    const key=JSON.stringify([config.sponsorType,path,safePath(config.logo)]);
    if(key===sponsorMediaKey)return;
    sponsorMediaKey=key;
    embed.style.display='none';embed.removeAttribute('src');
    video.pause(); video.removeAttribute('src'); video.load();
    image.hidden = false; video.style.display = 'none';
    image.src = safePath(config.logo) || fallbackLogo;
    if (!path) {image.hidden=document.body.classList.contains('preview-mode');return;}
    if(config.sponsorType==='embed' && safeHttp(path)){image.hidden=true;embed.style.display='block';embed.src=path;}
    else if (config.sponsorType === 'video') {image.hidden=true;video.style.display='block';video.src=path;video.muted=true;video.play().catch(()=>{});}
    else image.src=path;
  }
  function customMedia(positions){
    for(const key of ['custom1','custom2','custom3']){
      const role=config.slotContent[key],node=panel(key),box=positions[key],url=config.customSlotMedia?.[key]?.url||'';
      if(!node)continue;
      Object.assign(node.style,{left:box.x+'px',top:box.y+'px',width:box.width+'px',height:box.height+'px',padding:'0'});
      const mediaKey=JSON.stringify([role,safePath(url),document.body.classList.contains('preview-mode')]);
      if(mediaKey===customMediaKeys[key])continue;
      customMediaKeys[key]=mediaKey;
      const image=node.querySelector('img'),video=node.querySelector('video'),embed=node.querySelector('iframe'),label=node.querySelector('.preview-label');
      video.pause();video.removeAttribute('src');video.load();image.removeAttribute('src');embed.removeAttribute('src');
      for(const element of [image,video,embed,label])element.style.display='none';
      node.hidden=config.panelEnabled?.[key]===false||!['image','video','browser','source'].includes(role);
      if(role==='image'&&safePath(url)){image.src=url;Object.assign(image.style,{display:'block',width:'100%',height:'100%',objectFit:'cover'});}
      if(role==='video'&&safePath(url)){video.src=url;video.muted=true;Object.assign(video.style,{display:'block',width:'100%',height:'100%',objectFit:'cover'});video.play().catch(()=>{});}
      if(role==='browser'&&document.body.classList.contains('preview-mode')&&safeHttp(url)){embed.src=url;Object.assign(embed.style,{display:'block',width:'100%',height:'100%',border:'0'});}
      if(document.body.classList.contains('preview-mode')&&role==='source'){label.textContent='OBS SOURCE · '+key.toUpperCase();label.style.display='flex';}
    }
  }
  function previewLayers(positions){
    if(!document.body.classList.contains('preview-mode'))return;
    const background=config.globalStyle?.background||{};
    const wallpaper=$('preview-wallpaper');
    const backgroundPath=['file','url'].includes(background.mode)?safePath(background.url||config.backgroundImage):'';
    wallpaper.hidden=!backgroundPath;
    if(backgroundPath)wallpaper.src=backgroundPath;
    else wallpaper.removeAttribute('src');
    canvas.style.background=background.mode==='gradient'
      ?window.KMGGradient.css(background)
      :background.mode==='solid'&&/^#[0-9a-f]{6}$/i.test(background.color)?background.color:'#000000';
    window.Background?.applyConfig(config);
    const strokes=$('preview-strokes');
    strokes.replaceChildren();
    for(const key of ['game','custom1','custom2','custom3','chat','translation','hand']){
      if(config.panelEnabled?.[key]===false)continue;
      const box=positions[key],override=config.regionStyleOverrides?.[key]===true;
      const local=config.regionBackgrounds?.[key]||{},regionalStroke=override?local.stroke:undefined;
      const globalStroke=regionalStroke||(!override?config.globalStyle?.stroke:null);
      const mode=globalStroke?.mode||(local.borderVisible===false?'none':'solid');
      if(mode==='none')continue;
      const width=Math.max(0,Math.min(32,Number(globalStroke?.width??4)));
      if(!width)continue;
      const tile=document.createElement('div');
      tile.className='preview-stroke-tile'+(mode==='gradient'?' gradient-stroke':'');
      const color=globalStroke?.color||local.borderColor||'#ffffff';
      Object.assign(tile.style,{left:box.x+'px',top:box.y+'px',width:box.width+'px',height:box.height+'px',borderWidth:mode==='gradient'?'0':width+'px',borderColor:/^#[0-9a-f]{6}$/i.test(color)?color:'#ffffff',opacity:String(Math.max(0,Math.min(100,Number(globalStroke?.opacity??100)))/100)});
      if(mode==='gradient'){
        tile.style.setProperty('--stroke-width',width+'px');
        tile.style.setProperty('--stroke-gradient',window.KMGGradient.css(globalStroke));
      }
      strokes.append(tile);
    }
  }
  function applyConfig(update = {}) {
    const source=update.layoutVersion?update:defaults;
    const positions=source.layoutVersion===3?OverlayEvents.validateLayout(source.layout):OverlayEvents.resolveLayout(source.layoutVersion===2?source.layout:undefined);
    config = {...defaults,...update};
    config.cameraMode=update.cameraMode??(Object.hasOwn(update,'handcam')?(config.handcam?'camera':'none'):defaults.cameraMode??(config.handcam?'camera':'none'));
    config.slotContent=OverlayEvents.resolveSlots(source.layoutVersion>=2?source.slotContent:undefined);
    previewLayers(positions);
    const slotFor=role=>Object.keys(config.slotContent).find(slot=>config.slotContent[slot]===role);
    if(!Array.isArray(config.platforms))config.platforms=defaults.platforms;
    const layout=OverlayEvents.handcamLayout();
    canvas.style.setProperty('--hand-height',layout.handHeight+'px');
    for(const region of ['game','chat','translation','hand']){const box=positions[region];Object.assign(panel(region).style,{left:box.x+'px',top:box.y+'px',width:box.width+'px',height:box.height+'px'});}
    for(const [region,slot] of [['sponsor',slotFor('sponsor')],['alerts',slotFor('alerts')]])if(slot){const box=positions[slot];Object.assign(panel(region).style,{left:box.x+'px',top:box.y+'px',width:box.width+'px',height:box.height+'px'});}
    customMedia(positions);
    const standalone=document.body.classList.contains('demo');
    for(const region of (standalone?['game','chat','translation','hand','custom1','custom2','custom3']:[])){
      const node=panel(region),style=config.regionBackgrounds?.[region]||{};
      if(node){node.style.borderColor=/^#[0-9a-f]{6}$/i.test(style.borderColor)?style.borderColor:'#ffffff';node.style.borderWidth=style.borderVisible===false?'0':'4px';}
    }
    if(standalone)for(const [region,slot] of [['sponsor',slotFor('sponsor')],['alerts',slotFor('alerts')]])if(slot){const node=panel(region),style=config.regionBackgrounds?.[slot]||{};node.style.borderColor=/^#[0-9a-f]{6}$/i.test(style.borderColor)?style.borderColor:'#ffffff';node.style.borderWidth=style.borderVisible===false?'0':'4px';}
    document.querySelector('.hand .preview-label').textContent=config.cameraMode==='reactive'?'DISCORD REACTIVE · OBS':'CAM · 440 × 318';
    for(const key of ['accent','panel','text']) if (/^#[0-9a-f]{6}$/i.test(config[key])) canvas.style.setProperty('--'+key,config[key]);
    $('player-name').textContent=config.name;
    $('brand-logo').src=safePath(config.logo)||fallbackLogo;
    panel('game').style.visibility=config.panelEnabled?.game===false?'hidden':'visible';
    panel('hand').style.visibility=config.panelEnabled?.hand===false||config.cameraMode==='none'?'hidden':'visible';
    for(const [region,key] of [['translation','showSubtitles'],['chat','showChat']]) panel(region).style.visibility=config.panelEnabled?.[region]!==false&&config[key] ? 'visible':'hidden';
    panel('sponsor').style.visibility=slotFor('sponsor')&&config.panelEnabled?.[slotFor('sponsor')]!==false&&config.showSponsor?'visible':'hidden';
    panel('alerts').style.visibility=slotFor('alerts')&&config.panelEnabled?.[slotFor('alerts')]!==false&&config.showAlerts?'visible':'hidden';
    if(!config.showAlerts){queue=[];clearTimeout(timer);timer=null;$('alert-default').hidden=false;$('alert-active').hidden=true;}
    queue=queue.filter(event=>config.platforms.includes(event.platform));
    media();
    if(document.body.classList.contains('preview-mode')&&!timer&&!queue.length)$('alert-default').hidden=true;
    render();
  }
  function render() {
    const chat=$('chat-feed'), subs=$('subtitles');chat.replaceChildren();subs.replaceChildren();
    for(const event of history) {
      if(event.type==='chat' && config.platforms.includes(event.platform)) {
        const row=document.createElement('div');row.className='chat-line';
        const badge=document.createElement('img');badge.className='platform-logo';badge.alt=labels[event.platform];badge.src='assets/'+event.platform+(event.platform==='soop'?'.ico':'.png');
        const nick=document.createElement('strong');nick.textContent=event.nickname;nick.style.color=OverlayEvents.nicknameColor(event.platform,event.nickname,config.nicknameColor);
        const text=document.createElement('p');text.textContent=event.text;
        row.append(badge);if(config.showNicknames)row.append(nick);row.append(text);chat.append(row);
      } else if(event.type==='subtitle') {
        const row=document.createElement('div');row.className='subtitle-line';
        const time=document.createElement('time');time.dateTime=new Date(event.timestamp).toISOString();time.textContent=new Date(event.timestamp).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit'});row.append(time);
        const text=document.createElement('p');text.textContent=event.text;row.append(text);subs.append(row);
      }
    }
    chat.scrollTop=chat.scrollHeight;subs.scrollTop=subs.scrollHeight;
  }
  function nextAlert() {
    timer=null;
    const event=queue.shift();
    $('alert-default').hidden=!!event||document.body.classList.contains('preview-mode');$('alert-active').hidden=!event;
    if(!event)return;
    $('alert-kind').textContent=`${labels[event.platform]} · ${event.type==='subscription'?'SUBSCRIPTION':'SUPPORT'}`;
    $('alert-name').textContent=event.nickname;$('alert-text').textContent=event.text;$('alert-active').scrollTop=0;
    timer=setTimeout(nextAlert,Math.max(1500,Math.min(Number(config.alertDuration)||7000,30000)));
  }
  function receive(input) {
    const event=OverlayEvents.normalizeEvent(input);if(!event||!store.accept(event))return false;
    history.push(event);if(history.length>100)history.shift();
    if((event.type==='donation'||event.type==='subscription')&&config.showAlerts&&config.platforms.includes(event.platform)) {if(queue.length<20)queue.push(event);if(!timer)nextAlert();}
    render();return true;
  }
  function clear() {history=[];queue=[];clearTimeout(timer);timer=null;nextAlert();render();}
  $('brand-logo')?.addEventListener('error',()=>{if(!$('brand-logo').src.endsWith('/'+fallbackLogo))$('brand-logo').src=fallbackLogo;});
  $('preview-wallpaper')?.addEventListener('error',()=>{$('preview-wallpaper').hidden=true;});
  $('sponsor-image')?.addEventListener('error',()=>{if(!$('sponsor-image').src.endsWith('/'+fallbackLogo))$('sponsor-image').src=fallbackLogo;});
  $('sponsor-video')?.addEventListener('error',()=>{$('sponsor-video').style.display='none';$('sponsor-image').hidden=false;$('sponsor-image').src=fallbackLogo;});
  for(const key of ['custom1','custom2','custom3']){const node=panel(key);if(!node)continue;for(const tag of ['img','video'])node.querySelector(tag)?.addEventListener('error',event=>{event.currentTarget.style.display='none';});}
  window.Overlay={receive,applyConfig,clear,getConfig:()=>({...config})};
  addEventListener('message',event=>{if(event.source!==parent||event.data?.channel!=='kmg-preview')return;const {action,data}=event.data;if(action==='apply')applyConfig(data);else if(action==='receive')receive(data);else if(action==='clear')clear();});
  if(new URLSearchParams(location.search).has('preview'))document.body.classList.add('preview-mode');
  applyConfig();
})();
