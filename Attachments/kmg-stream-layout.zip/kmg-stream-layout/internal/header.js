(() => { const source=document.currentScript; source.insertAdjacentHTML('beforebegin',"<header class=\"app-header\"><div class=\"brand\"><h1>KMG’s Streaming Template</h1><span id=\"app-version\"></span></div><nav class=\"header-tools\" aria-label=\"도구\">\r\n<button id=\"github-link\" class=\"icon-button\" type=\"button\" disabled aria-label=\"GitHub\"><svg class=\"button-svg\" aria-hidden=\"true\" focusable=\"false\" width=\"32\" height=\"32\" viewBox=\"16 16 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n<g clip-path=\"url(#clip0_17_21)\">\r\n<path d=\"M28 41.3333C21.3333 43.3333 21.3333 38 18.6666 37.3333M37.3333 45.3333V40.1733C37.3833 39.5376 37.2974 38.8984 37.0813 38.2984C36.8652 37.6984 36.5239 37.1512 36.08 36.6933C40.2666 36.2267 44.6666 34.64 44.6666 27.36C44.6663 25.4984 43.9502 23.7083 42.6666 22.36C43.2744 20.7313 43.2315 18.9311 42.5466 17.3333C42.5466 17.3333 40.9733 16.8667 37.3333 19.3067C34.2773 18.4784 31.0559 18.4784 28 19.3067C24.36 16.8667 22.7866 17.3333 22.7866 17.3333C22.1018 18.9311 22.0588 20.7313 22.6666 22.36C21.3735 23.7183 20.6567 25.5246 20.6666 27.4C20.6666 34.6267 25.0666 36.2133 29.2533 36.7333C28.8146 37.1866 28.4763 37.7272 28.2604 38.3199C28.0444 38.9126 27.9557 39.5441 28 40.1733V45.3333\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n</g>\r\n<defs>\r\n<clipPath id=\"clip0_17_21\">\r\n<rect width=\"32\" height=\"32\" fill=\"white\" transform=\"translate(16 16)\"/>\r\n</clipPath>\r\n</defs>\r\n</svg></button><a id=\"settings-link\" class=\"icon-button\" href=\"preview.html\" aria-label=\"설정 페이지\"><svg class=\"button-svg header-icon--settings\" aria-hidden=\"true\" focusable=\"false\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M16 20C18.2092 20 20 18.2091 20 16C20 13.7909 18.2092 12 16 12C13.7909 12 12 13.7909 12 16C12 18.2091 13.7909 20 16 20Z\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M25.8667 20C25.6892 20.4022 25.6363 20.8483 25.7147 21.2808C25.7931 21.7133 25.9993 22.1124 26.3067 22.4267L26.3867 22.5067C26.6346 22.7543 26.8313 23.0484 26.9655 23.3722C27.0997 23.6959 27.1688 24.0429 27.1688 24.3933C27.1688 24.7438 27.0997 25.0908 26.9655 25.4145C26.8313 25.7382 26.6346 26.0323 26.3867 26.28C26.139 26.5279 25.8449 26.7246 25.5212 26.8588C25.1975 26.993 24.8505 27.0621 24.5 27.0621C24.1496 27.0621 23.8026 26.993 23.4789 26.8588C23.1551 26.7246 22.861 26.5279 22.6134 26.28L22.5334 26.2C22.2191 25.8926 21.82 25.6864 21.3875 25.608C20.955 25.5296 20.5089 25.5825 20.1067 25.76C19.7123 25.929 19.376 26.2097 19.1391 26.5674C18.9022 26.9251 18.7751 27.3443 18.7734 27.7733V28C18.7734 28.7072 18.4924 29.3855 17.9923 29.8856C17.4922 30.3857 16.814 30.6667 16.1067 30.6667C15.3995 30.6667 14.7212 30.3857 14.2211 29.8856C13.721 29.3855 13.44 28.7072 13.44 28V27.88C13.4297 27.4387 13.2869 27.0107 13.0301 26.6516C12.7732 26.2925 12.4144 26.019 12 25.8667C11.5979 25.6892 11.1518 25.6362 10.7193 25.7147C10.2867 25.7931 9.88761 25.9993 9.57337 26.3067L9.49337 26.3867C9.24571 26.6346 8.95161 26.8313 8.62788 26.9655C8.30415 27.0997 7.95715 27.1688 7.60671 27.1688C7.25627 27.1688 6.90926 27.0997 6.58553 26.9655C6.2618 26.8313 5.9677 26.6346 5.72004 26.3867C5.4721 26.139 5.27541 25.8449 5.14121 25.5212C5.00702 25.1974 4.93794 24.8504 4.93794 24.5C4.93794 24.1496 5.00702 23.8026 5.14121 23.4788C5.27541 23.1551 5.4721 22.861 5.72004 22.6133L5.80004 22.5333C6.10742 22.2191 6.31362 21.82 6.39205 21.3875C6.47047 20.9549 6.41753 20.5088 6.24004 20.1067C6.07102 19.7123 5.79038 19.376 5.43266 19.1391C5.07494 18.9022 4.65576 18.775 4.22671 18.7733H4.00004C3.2928 18.7733 2.61452 18.4924 2.11442 17.9923C1.61433 17.4922 1.33337 16.8139 1.33337 16.1067C1.33337 15.3994 1.61433 14.7211 2.11442 14.221C2.61452 13.721 3.2928 13.44 4.00004 13.44H4.12004C4.56137 13.4297 4.98938 13.2868 5.34844 13.03C5.7075 12.7732 5.981 12.4143 6.13337 12C6.31086 11.5978 6.36381 11.1517 6.28538 10.7192C6.20696 10.2867 6.00076 9.88757 5.69337 9.57333L5.61337 9.49333C5.36544 9.24567 5.16875 8.95157 5.03455 8.62784C4.90035 8.30411 4.83128 7.95711 4.83128 7.60667C4.83128 7.25622 4.90035 6.90922 5.03455 6.58549C5.16875 6.26176 5.36544 5.96766 5.61337 5.72C5.86104 5.47206 6.15514 5.27537 6.47887 5.14117C6.80259 5.00697 7.1496 4.9379 7.50004 4.9379C7.85048 4.9379 8.19749 5.00697 8.52121 5.14117C8.84494 5.27537 9.13905 5.47206 9.38671 5.72L9.46671 5.8C9.78095 6.10738 10.1801 6.31358 10.6126 6.392C11.0451 6.47043 11.4912 6.41749 11.8934 6.24H12C12.3944 6.07098 12.7307 5.79034 12.9676 5.43262C13.2045 5.0749 13.3317 4.65571 13.3334 4.22667V4C13.3334 3.29275 13.6143 2.61448 14.1144 2.11438C14.6145 1.61428 15.2928 1.33333 16 1.33333C16.7073 1.33333 17.3856 1.61428 17.8857 2.11438C18.3858 2.61448 18.6667 3.29275 18.6667 4V4.12C18.6684 4.54905 18.7956 4.96823 19.0325 5.32595C19.2694 5.68367 19.6057 5.96432 20 6.13333C20.4022 6.31082 20.8483 6.36376 21.2808 6.28534C21.7134 6.20691 22.1125 6.00071 22.4267 5.69333L22.5067 5.61333C22.7544 5.3654 23.0485 5.1687 23.3722 5.03451C23.6959 4.90031 24.0429 4.83123 24.3934 4.83123C24.7438 4.83123 25.0908 4.90031 25.4145 5.03451C25.7383 5.1687 26.0324 5.3654 26.28 5.61333C26.528 5.86099 26.7247 6.1551 26.8589 6.47882C26.9931 6.80255 27.0621 7.14956 27.0621 7.5C27.0621 7.85044 26.9931 8.19744 26.8589 8.52117C26.7247 8.8449 26.528 9.139 26.28 9.38667L26.2 9.46667C25.8927 9.7809 25.6865 10.18 25.608 10.6125C25.5296 11.0451 25.5826 11.4912 25.76 11.8933V12C25.9291 12.3944 26.2097 12.7307 26.5674 12.9676C26.9251 13.2045 27.3443 13.3316 27.7734 13.3333H28C28.7073 13.3333 29.3856 13.6143 29.8857 14.1144C30.3858 14.6145 30.6667 15.2928 30.6667 16C30.6667 16.7072 30.3858 17.3855 29.8857 17.8856C29.3856 18.3857 28.7073 18.6667 28 18.6667H27.88C27.451 18.6684 27.0318 18.7955 26.6741 19.0324C26.3164 19.2693 26.0357 19.6056 25.8667 20Z\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg></a><a id=\"guide-link\" class=\"icon-button\" href=\"guide.html\" aria-label=\"세팅 가이드\"><svg class=\"button-svg\" aria-hidden=\"true\" focusable=\"false\" width=\"32\" height=\"32\" viewBox=\"16 16 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n<path d=\"M28.12 28C28.4334 27.1089 29.0522 26.3575 29.8666 25.8788C30.681 25.4002 31.6385 25.2253 32.5695 25.3849C33.5006 25.5446 34.345 26.0287 34.9534 26.7514C35.5617 27.474 35.8947 28.3887 35.8933 29.3333C35.8933 32 31.8933 33.3333 31.8933 33.3333M32 38.6667H32.0133M45.3333 32C45.3333 39.3638 39.3638 45.3333 32 45.3333C24.6362 45.3333 18.6666 39.3638 18.6666 32C18.6666 24.6362 24.6362 18.6667 32 18.6667C39.3638 18.6667 45.3333 24.6362 45.3333 32Z\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n</svg></a><label class=\"icon-button icon-picker\" aria-label=\"언어\"><svg class=\"button-svg\" aria-hidden=\"true\" focusable=\"false\" width=\"32\" height=\"32\" viewBox=\"16 16 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n<path d=\"M45.3333 32C45.3333 39.3638 39.3638 45.3333 32 45.3333M45.3333 32C45.3333 24.6362 39.3638 18.6667 32 18.6667M45.3333 32H18.6666M32 45.3333C24.6362 45.3333 18.6666 39.3638 18.6666 32M32 45.3333C35.335 41.6822 37.2303 36.944 37.3333 32C37.2303 27.056 35.335 22.3178 32 18.6667M32 45.3333C28.6649 41.6822 26.7696 36.944 26.6666 32C26.7696 27.056 28.6649 22.3178 32 18.6667M18.6666 32C18.6666 24.6362 24.6362 18.6667 32 18.6667\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n</svg><select id=\"ui-language\" aria-label=\"언어\"><option value=\"ko\">한국어</option><option value=\"en\">English</option><option value=\"ja\">日本語</option></select></label><button id=\"theme-toggle\" class=\"icon-button\" type=\"button\" aria-label=\"라이트/다크 모드\"><svg class=\"button-svg\" aria-hidden=\"true\" focusable=\"false\" width=\"32\" height=\"32\" viewBox=\"16 16 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n<g clip-path=\"url(#clip0_17_25)\">\r\n<path d=\"M32 17.3333V20M32 44V46.6667M21.6267 21.6267L23.52 23.52M40.48 40.48L42.3734 42.3733M17.3334 32H20M44 32H46.6667M21.6267 42.3733L23.52 40.48M40.48 23.52L42.3734 21.6267M38.6667 32C38.6667 35.6819 35.6819 38.6667 32 38.6667C28.3181 38.6667 25.3334 35.6819 25.3334 32C25.3334 28.3181 28.3181 25.3333 32 25.3333C35.6819 25.3333 38.6667 28.3181 38.6667 32Z\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n</g>\r\n<defs>\r\n<clipPath id=\"clip0_17_25\">\r\n<rect width=\"32\" height=\"32\" fill=\"white\" transform=\"translate(16 16)\"/>\r\n</clipPath>\r\n</defs>\r\n</svg></button><label class=\"icon-button icon-picker\" aria-label=\"강조 색상\"><svg xmlns=\"http://www.w3.org/2000/svg\" class=\"button-svg\" width=\"32\" height=\"32\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"13.5\" cy=\"6.5\" r=\".5\"/><circle cx=\"17.5\" cy=\"10.5\" r=\".5\"/><circle cx=\"8.5\" cy=\"7.5\" r=\".5\"/><circle cx=\"6.5\" cy=\"12.5\" r=\".5\"/><path d=\"M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z\"/></svg><input id=\"accent-color\" type=\"color\" value=\"#d4ff00\"></label><button id=\"html-background\" class=\"icon-button\" type=\"button\" aria-label=\"배경 설정으로 이동\"><svg class=\"button-svg header-icon--background\" aria-hidden=\"true\" focusable=\"false\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M25.3333 4H6.66667C5.19391 4 4 5.19391 4 6.66667V25.3333C4 26.8061 5.19391 28 6.66667 28H25.3333C26.8061 28 28 26.8061 28 25.3333V6.66667C28 5.19391 26.8061 4 25.3333 4Z\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg></button>\r\n</nav></header>"); })();

(() => {
  const header=document.querySelector('.app-header');
  for(const icon of header.querySelectorAll('.button-svg')){icon.setAttribute('width','32');icon.setAttribute('height','32');icon.setAttribute('aria-hidden','true');icon.setAttribute('focusable','false');if(icon.getAttribute('viewBox')==='0 0 64 64')icon.setAttribute('viewBox','16 16 32 32');}
  const version=header.querySelector('#app-version');
  version.textContent='v'+(window.KMG_VERSION||'0.0.0');
  const themeButton=header.querySelector('#theme-toggle');
  const sun=themeButton.querySelector('svg');
  sun.classList.add('theme-icon-sun');
  const moon=document.createElementNS('http://www.w3.org/2000/svg','svg');
  moon.setAttribute('viewBox','0 0 32 32');
  moon.setAttribute('width','32');
  moon.setAttribute('height','32');
  moon.setAttribute('class','button-svg theme-icon-moon');
  moon.setAttribute('aria-hidden','true');
  moon.setAttribute('focusable','false');
  moon.setAttribute('fill','none');
  const moonPath=document.createElementNS('http://www.w3.org/2000/svg','path');
  moonPath.setAttribute('d','M28 17.0533C27.7902 19.3229 26.9385 21.4859 25.5443 23.2891C24.1502 25.0922 22.2713 26.4611 20.1276 27.2354C17.9839 28.0097 15.664 28.1575 13.4393 27.6615C11.2147 27.1654 9.17732 26.0461 7.56562 24.4344C5.95393 22.8227 4.83458 20.7853 4.33853 18.5607C3.84249 16.336 3.99028 14.0161 4.7646 11.8724C5.53893 9.72868 6.90777 7.84982 8.71094 6.45567C10.5141 5.06152 12.6771 4.20974 14.9467 4C13.6179 5.79769 12.9785 8.0126 13.1447 10.2419C13.3109 12.4712 14.2718 14.5667 15.8525 16.1475C17.4332 17.7282 19.5288 18.689 21.7581 18.8553C23.9874 19.0215 26.2023 18.3821 28 17.0533Z');
  moonPath.setAttribute('stroke','currentColor');
  moonPath.setAttribute('stroke-width','3');
  moonPath.setAttribute('stroke-linecap','round');
  moonPath.setAttribute('stroke-linejoin','round');
  moon.append(moonPath);
  themeButton.append(moon);
  function setTheme(value){
    document.body.dataset.theme=value;
    themeButton.setAttribute('aria-label',value==='light'?'어두운 테마로 전환':'밝은 테마로 전환');
    try{localStorage.setItem('overlay-ui-theme',value);}catch{}
  }
  let savedTheme='dark';
  try{savedTheme=localStorage.getItem('overlay-ui-theme')==='light'?'light':'dark';}catch{}
  setTheme(savedTheme);
  themeButton.addEventListener('click',()=>setTheme(document.body.dataset.theme==='light'?'dark':'light'));
  const accentInput=header.querySelector('#accent-color');
  try{const saved=localStorage.getItem('overlay-ui-accent');if(/^#[0-9a-f]{6}$/i.test(saved||'')){accentInput.value=saved;document.documentElement.style.setProperty('--accent',saved);}}catch{}
  accentInput.addEventListener('input',()=>{const value=accentInput.value;document.documentElement.style.setProperty('--accent',value);try{localStorage.setItem('overlay-ui-accent',value);}catch{}});
  const settingsLink=header.querySelector('#settings-link');
  const guideLink=header.querySelector('#guide-link');
  const currentPath=location.pathname.replace(/\/+$/,'')||'/';
  const settingsPath=new URL(settingsLink.href,location.href).pathname.replace(/\/+$/,'')||'/';
  const guidePath=/\/guide(?:-(?:en|ja))?\.html$/i.test(currentPath);
  const disableCurrentLink=(link,isCurrent)=>{if(!isCurrent)return;link.setAttribute('aria-current','page');link.setAttribute('aria-disabled','true');link.setAttribute('tabindex','-1');link.addEventListener('click',event=>event.preventDefault());};
  disableCurrentLink(settingsLink,currentPath===settingsPath);
  disableCurrentLink(guideLink,guidePath);
  const backgroundButton=header.querySelector('#html-background');
  backgroundButton.setAttribute('aria-label','설정 화면 배경');
  const dialog=document.createElement('dialog');
  dialog.className='page-background-dialog';
  dialog.innerHTML=`<div class="page-background-head"><h2>설정 화면 배경</h2><button class="page-background-close" type="button" aria-label="닫기">×</button></div>
    <p>이 HTML 화면에만 적용됩니다. OBS 방송 배경은 전역 설정에서 바꾸세요.</p>
    <div class="page-background-options" role="radiogroup" aria-label="배경 종류">
      <label><input type="radio" name="page-background-mode" value="solid" checked>단색</label>
      <label><input type="radio" name="page-background-mode" value="gradient">그라데이션</label>
      <label><input type="radio" name="page-background-mode" value="file">이미지 파일</label>
      <label><input type="radio" name="page-background-mode" value="url">이미지 URL</label>
    </div>
    <div class="page-background-fields">
      <label class="page-background-primary">첫 번째 색상<input id="page-background-primary" type="color" class="color-swatch" value="#000000"></label>
      <label class="page-background-secondary">두 번째 색상<input id="page-background-secondary" type="color" class="color-swatch" value="#202020"></label>
      <button id="page-background-gradient-edit" class="page-background-gradient-edit" type="button" aria-label="그라디언트 편집" hidden></button>
      <label class="page-background-file">이미지 파일<input id="page-background-file" type="file" accept="image/png,image/jpeg,image/webp,image/gif"></label>
      <label class="page-background-url">이미지 URL<input id="page-background-url" type="url" placeholder="https://…"></label>
    </div>
    <p id="page-background-status" role="status"></p>
    <div class="page-background-actions"><button id="page-background-reset" type="button">기본 배경</button><button id="page-background-apply" type="button">적용</button></div>`;
  document.body.append(dialog);
  const stateKey='overlay-ui-page-background';
  const radios=[...dialog.querySelectorAll('input[name="page-background-mode"]')];
  const primary=dialog.querySelector('#page-background-primary');
  const secondary=dialog.querySelector('#page-background-secondary');
  const file=dialog.querySelector('#page-background-file');
  const gradientButton=dialog.querySelector('#page-background-gradient-edit');
  const url=dialog.querySelector('#page-background-url');
  const status=dialog.querySelector('#page-background-status');
  const applyButton=dialog.querySelector('#page-background-apply');
  const resetButton=dialog.querySelector('#page-background-reset');
  let fileUrl='';
  let applyingBackground=false;
  let resettingBackground=false;
  let saved={mode:'default',color:'#000000',color2:'#202020',url:''};
  try{saved={...saved,...JSON.parse(localStorage.getItem(stateKey)||'{}')};}catch{}
  let gradientDraft=saved.gradient?window.KMGGradient?.normalize({gradient:saved.gradient}):null;
  function setGradient(value){
    if(!window.KMGGradient)return;
    gradientDraft=window.KMGGradient.normalize({gradient:value});
    gradientButton.style.backgroundImage=window.KMGGradient.css({gradient:gradientDraft});
  }
  function openGradient(){
    if(!window.KMGGradient?.open){status.textContent='그라디언트 편집기를 불러오지 못했습니다.';return;}
    const part={mode:'gradient',color:saved.color,color2:saved.color2,gradient:gradientDraft||window.KMGGradient.normalize({mode:'gradient',color:saved.color,color2:saved.color2})};
    setGradient(part.gradient);
    window.KMGGradient.open(gradientButton,part,setGradient);
  }
  function showFields(){
    const mode=radios.find(radio=>radio.checked)?.value||'solid';
    dialog.querySelector('.page-background-primary').hidden=mode!=='solid';
    dialog.querySelector('.page-background-secondary').hidden=true;
    gradientButton.hidden=mode!=='gradient';
    dialog.querySelector('.page-background-file').hidden=mode!=='file';
    dialog.querySelector('.page-background-url').hidden=mode!=='url';
  }
  function imageUrl(value){
    if(/^assets\/(?!.*\.\.)[\w./-]+$/i.test(value))return value;
    try{const parsed=new URL(value);return ['http:','https:'].includes(parsed.protocol)&&!parsed.username&&!parsed.password?parsed.href:'';}catch{return '';}
  }
  function waitForImage(src,timeout=15000){
    return new Promise((resolve,reject)=>{
      const image=new Image();
      let settled=false;
      const finish=(error)=>{
        if(settled)return;
        settled=true;clearTimeout(timer);image.onload=null;image.onerror=null;
        if(error)reject(error);else resolve(image);
      };
      const timer=setTimeout(()=>finish(new Error('image timeout')),timeout);
      image.onload=()=>{
        Promise.resolve(typeof image.decode==='function'?image.decode():undefined)
          .then(()=>finish(),()=>finish(new Error('image decode failed')));
      };
      image.onerror=()=>finish(new Error('image load failed'));
      image.src=src;
      if(image.complete){if(image.naturalWidth>0)image.onload();else image.onerror();}
    });
  }
  function paint(value,blobUrl=''){
    const body=document.body;
    body.style.backgroundColor='';body.style.backgroundImage='';body.style.backgroundSize='';body.style.backgroundPosition='';body.style.backgroundAttachment='';
    if(value.mode==='solid')body.style.backgroundColor=value.color;
    if(value.mode==='gradient')body.style.backgroundImage=window.KMGGradient?.css(value.gradient?{gradient:value.gradient}:value)||`linear-gradient(135deg, ${value.color}, ${value.color2})`;
    const image=value.mode==='file'?blobUrl:value.mode==='url'?imageUrl(value.url):'';
    if(image){body.style.backgroundImage=`url(${JSON.stringify(image)})`;body.style.backgroundSize='cover';body.style.backgroundPosition='center';body.style.backgroundAttachment='fixed';}
  }
  function database(){return new Promise((resolve,reject)=>{const request=indexedDB.open('kmg-stream-layout',1);request.onupgradeneeded=()=>{if(!request.result.objectStoreNames.contains('files'))request.result.createObjectStore('files');};request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});}
  async function fileStore(action,blob){
    const db=await database();
    try{
      return await new Promise((resolve,reject)=>{
        const tx=db.transaction('files',action==='read'?'readonly':'readwrite');
        const store=tx.objectStore('files');
        const request=action==='read'?store.get('page-background'):action==='delete'?store.delete('page-background'):store.put(blob,'page-background');
        let result;
        request.onsuccess=()=>{result=request.result;};
        request.onerror=()=>reject(request.error||new Error('IndexedDB request failed'));
        tx.oncomplete=()=>resolve(result);
        tx.onerror=()=>reject(tx.error||new Error('IndexedDB transaction failed'));
        tx.onabort=()=>reject(tx.error||new Error('IndexedDB transaction aborted'));
      });
    }finally{db.close();}
  }
  async function restoreFile(){
    if(saved.mode!=='file')return paint(saved);
    try{const blob=await fileStore('read');if(blob){fileUrl=URL.createObjectURL(blob);paint(saved,fileUrl);}}catch{status.textContent='저장된 이미지 파일을 불러오지 못했습니다.';}
  }
  if(saved.mode==='gradient'&&!gradientDraft){gradientDraft=window.KMGGradient?.normalize(saved)||null;if(gradientDraft)saved.gradient=gradientDraft;}
  if(gradientDraft)setGradient(gradientDraft);
  primary.value=/^#[0-9a-f]{6}$/i.test(saved.color)?saved.color:'#000000';
  secondary.value=/^#[0-9a-f]{6}$/i.test(saved.color2)?saved.color2:'#202020';
  url.value=saved.url||'';
  (radios.find(radio=>radio.value===saved.mode)||radios[0]).checked=true;
  radios.forEach(radio=>radio.addEventListener('change',()=>{showFields();if(radio.checked&&radio.value==='gradient')openGradient();}));
  gradientButton.addEventListener('click',openGradient);
  showFields();restoreFile();
  backgroundButton.addEventListener('click',()=>{status.textContent='';dialog.showModal();});
  dialog.querySelector('.page-background-close').addEventListener('click',()=>dialog.close());
  dialog.addEventListener('click',event=>{if(event.target===dialog)dialog.close();});
  resetButton.addEventListener('click',async()=>{
    if(applyingBackground||resettingBackground)return;
    resettingBackground=true;resetButton.disabled=true;applyButton.disabled=true;
    try{
      try{localStorage.removeItem(stateKey);await fileStore('delete');}catch{}
      if(fileUrl){URL.revokeObjectURL(fileUrl);fileUrl='';}
      saved={mode:'default',color:'#000000',color2:'#202020',url:''};
      gradientDraft=null;radios[0].checked=true;primary.value=saved.color;secondary.value=saved.color2;url.value='';file.value='';gradientButton.style.backgroundImage='';showFields();paint(saved);dialog.close();
    }finally{resettingBackground=false;resetButton.disabled=false;applyButton.disabled=false;}
  });
  applyButton.addEventListener('click',async()=>{
    if(applyingBackground||resettingBackground)return;
    applyingBackground=true;applyButton.disabled=true;resetButton.disabled=true;
    applyButton.setAttribute('aria-busy','true');
    applyButton.setAttribute('aria-label',window.KMGI18n?.localize('적용 중')||'적용 중');
    applyButton.innerHTML='<span class="page-background-spinner" aria-hidden="true"></span>';
    status.textContent='';
    let candidateUrl='';
    let previousBlob;
    let fileWasWritten=false;
    let localStateWasWritten=false;
    let previousLocalState=null;
    try{
      await new Promise(resolve=>requestAnimationFrame(resolve));
      const mode=radios.find(radio=>radio.checked).value;
      const gradient=mode==='gradient'?(gradientDraft||window.KMGGradient?.normalize({mode:'gradient',color:saved.color,color2:saved.color2})):null;
      const next={mode,color:mode==='gradient'?gradient?.stops?.[0]?.color||saved.color:primary.value,color2:mode==='gradient'?gradient?.stops?.at(-1)?.color||saved.color2:secondary.value,url:url.value.trim(),...(gradient?{gradient}:{})};
      if(mode==='url'&&!imageUrl(next.url)){status.textContent='https:// 주소 또는 assets/ 경로를 입력하세요.';return;}
      let blob=null;
      if(mode==='file'){
        blob=file.files?.[0]||null;
        if(!blob&&!fileUrl){status.textContent='이미지 파일을 선택하세요.';return;}
        if(blob&&!/^image\/(png|jpeg|webp|gif)$/.test(blob.type)){status.textContent='PNG, JPEG, WebP 또는 GIF를 선택하세요.';return;}
        candidateUrl=blob?URL.createObjectURL(blob):fileUrl;
      }
      const previewImage=mode==='url'?imageUrl(next.url):mode==='file'?candidateUrl:'';
      if(previewImage){
        try{await waitForImage(previewImage);}catch{status.textContent='배경 이미지를 불러오지 못했습니다.';return;}
      }
      previousLocalState=localStorage.getItem(stateKey);
      if(blob){
        try{previousBlob=await fileStore('read');await fileStore('write',blob);fileWasWritten=true;}
        catch{status.textContent='이미지를 저장하지 못했습니다.';return;}
      }
      try{localStorage.setItem(stateKey,JSON.stringify(next));localStateWasWritten=true;}
      catch{
        if(fileWasWritten){try{if(previousBlob)await fileStore('write',previousBlob);else await fileStore('delete');fileWasWritten=false;}catch{}}
        status.textContent='설정을 저장하지 못했습니다.';return;
      }
      try{paint(next,candidateUrl||fileUrl);}
      catch{
        try{if(previousLocalState===null)localStorage.removeItem(stateKey);else localStorage.setItem(stateKey,previousLocalState);}catch{}
        if(fileWasWritten){try{if(previousBlob)await fileStore('write',previousBlob);else await fileStore('delete');}catch{}}
        status.textContent='배경을 적용하지 못했습니다.';return;
      }
      const previousUrl=fileUrl;
      if(blob)fileUrl=candidateUrl;
      candidateUrl='';saved=next;dialog.close();
      if(blob&&previousUrl&&previousUrl!==fileUrl){try{URL.revokeObjectURL(previousUrl);}catch{}}
    }catch{
      if(localStateWasWritten){try{if(previousLocalState===null)localStorage.removeItem(stateKey);else localStorage.setItem(stateKey,previousLocalState);}catch{}}
      if(fileWasWritten){try{if(previousBlob)await fileStore('write',previousBlob);else await fileStore('delete');}catch{}}
      status.textContent='배경을 적용하지 못했습니다.';
    }finally{
      if(candidateUrl&&candidateUrl!==fileUrl)URL.revokeObjectURL(candidateUrl);
      applyingBackground=false;applyButton.disabled=false;resetButton.disabled=false;
      applyButton.removeAttribute('aria-busy');applyButton.removeAttribute('aria-label');applyButton.textContent='적용';
    }
  });
})();
