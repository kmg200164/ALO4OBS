# Platform icons

Official website favicon assets, downloaded 2026-10-02. Platform trademarks belong to their owners.

- chzzk.png: https://ssl.pstatic.net/static/nng/glive/icon/favicon.png
- twitch.png: https://assets.twitch.tv/assets/favicon-32-e29e246c157142c94346.png
- youtube.png: https://www.youtube.com/s/desktop/2b888666/img/favicon_96x96.png
- soop.ico: https://res.sooplive.com/favicon.ico