window.KMG_VERSION = '0.4.0-dev.1';
