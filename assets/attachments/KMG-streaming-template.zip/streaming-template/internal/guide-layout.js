(() => {
  const description = '왼쪽 상위 프레임의 두 하위 프레임은 위 게임과 아래 커스텀 패널 묶음입니다. 묶음 안에는 1·2·3번 패널이 나란히 놓이고, 오른쪽 상위 프레임은 위 채팅·가운데 번역·아래 캠으로 나뉩니다.';
  document.querySelectorAll('[data-guide-layout]').forEach((mount,index) => {
    const figure = document.createElement('figure');
    figure.className = 'guide-layout-figure';
    figure.setAttribute('role','group');
    figure.setAttribute('aria-labelledby',`guide-layout-caption-${index}`);
    figure.innerHTML = `
      <div class="guide-layout-canvas" aria-hidden="true">
        <div class="guide-layout-parent guide-layout-parent--left">
          <div class="guide-layout-child guide-layout-game"></div>
          <div class="guide-layout-child guide-layout-custom-band">
            <div class="guide-layout-customs">
              <div class="guide-layout-custom-item"></div>
              <div class="guide-layout-custom-item"></div>
              <div class="guide-layout-custom-item"></div>
            </div>
          </div>
        </div>
        <div class="guide-layout-parent guide-layout-parent--right">
          <div class="guide-layout-child"></div>
          <div class="guide-layout-child"></div>
          <div class="guide-layout-child"></div>
        </div>
      </div>
      <figcaption class="guide-layout-caption" id="guide-layout-caption-${index}">
        <span class="guide-layout-description">${description}</span>
        <span class="guide-layout-legend">
          <span><i class="guide-layout-swatch guide-layout-swatch--parent" aria-hidden="true"></i>상위 프레임</span>
          <span><i class="guide-layout-swatch guide-layout-swatch--child" aria-hidden="true"></i>하위 프레임</span>
        </span>
      </figcaption>`;
    mount.replaceWith(figure);
  });
})();
