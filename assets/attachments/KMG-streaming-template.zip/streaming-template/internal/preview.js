(() => {
  const byId=id=>document.getElementById(id);
  const form=byId('settings'), frame=byId('preview'), status=byId('status');
  const keys=['game','custom1','custom2','custom3','chat','translation','hand'];
  const names={game:'게임',custom1:'커스텀 1',custom2:'커스텀 2',custom3:'커스텀 3',chat:'채팅',translation:'번역',hand:'캠'};
  const defaults=structuredClone(window.OVERLAY_PUBLIC_CONFIG);
  const sourceConfig=structuredClone(window.OVERLAY_CONFIG);
  const sourceFingerprint=sourceConfig?.layoutVersion===3?JSON.stringify(sourceConfig):'';
  const initialPlacement=OverlayEvents.defaultPlacement();
  const uploads=new Map();
  const uploadRequests=new Map();
  let config=structuredClone(defaults), selected=null, replay=null, sampleCount=0;
  let cameraState={status:'unavailable',devices:[],selectedDeviceId:'',errorName:'NotSupportedError'},cameraController=null,cameraActive=false;
  const cameraVideo=byId('camera-preview-video');
  byId('app-version').textContent='v'+window.KMG_VERSION;

  // The Figma path selectors are a hierarchy: side → row → slot. The layout
  // engine alone projects these groups to the OBS pixel coordinates.
  const levelOptions={
    level1:[['left','왼쪽'],['right','오른쪽']],
    level2:[['top','위'],['center','가운데'],['bottom','아래']]
  };
  const optionHtml=(items,value)=>items.map(([v,label])=>`<option value="${v}"${v===value?' selected':''}>${label}</option>`).join('');
  const send=(target,action,data)=>target.contentWindow?.postMessage({channel:'kmg-preview',action,data},'*');
  const control=(name)=>form.elements.namedItem(name);
  const defaultStyle={
    background:{mode:'solid',color:'#000000',color2:'#101010',url:''},
    fill:{mode:'solid',color:'#ffffff',color2:'#000000',opacity:20,blur:32},
    stroke:{mode:'solid',color:'#ffffff',color2:'#000000',opacity:100,width:4}
  };
  function normalize(input){
    const next={...structuredClone(defaults),...structuredClone(input||{})};
    next.layoutVersion=3;
    next.panelEnabled=Object.fromEntries(keys.map(key=>[key,next.panelEnabled?.[key]!==false]));
    next.panelPlacement=OverlayEvents.normalizePlacement(Object.fromEntries(keys.map(key=>[key,{...initialPlacement[key],...next.panelPlacement?.[key]}])));
    next.slotContent={...defaults.slotContent,...next.slotContent};
    next.customSlotMedia={...defaults.customSlotMedia,...next.customSlotMedia};
    next.regionBackgrounds={...defaults.regionBackgrounds,...next.regionBackgrounds};
    next.regionStyleOverrides={...next.regionStyleOverrides};
    next.globalStyle={
      background:{...defaultStyle.background,...next.globalStyle?.background},
      fill:{...defaultStyle.fill,...next.globalStyle?.fill},
      stroke:{...defaultStyle.stroke,...next.globalStyle?.stroke}
    };
    // Test lobby assets and personal settings never become the public reset.
    return next;
  }
  function restoredSettings(runtime,saved,savedSource){
    // Replacing config.js with an exported ZIP must beat an older browser draft.
    const exported=runtime?.layoutVersion===3?runtime:null;
    const fingerprint=exported?JSON.stringify(exported):'';
    if(saved?.layoutVersion===3&&(!exported||savedSource===fingerprint)){
      try{OverlayEvents.validateLayout(saved.layout);return saved;}catch{}
    }
    if(exported){try{OverlayEvents.validateLayout(exported.layout);return exported;}catch{}}
    return defaults;
  }
  function propertyRow(label,controlHtml,radioName,value,checked,choiceType='radio',variant=''){
    const choice=radioName?`<input type="${choiceType}" name="${radioName}"${choiceType==='checkbox'?'':` value="${value}"`}${checked?' checked':''}>`:'';
    return `<div class="property-row${variant?` ${variant}`:''}"><label>${choice}<span>${label}</span></label><div class="property-value">${controlHtml||''}</div></div>`;
  }
  const color=(name,value)=>`<span class="value-text" data-color-label="${name}">${value.toUpperCase()}</span><input name="${name}" type="color" class="color-swatch" value="${value}">`;
  const num=(name,value,unit,max)=>`<input name="${name}" type="number" min="0" max="${max}" value="${value}">${unit?`<span class="unit">${unit}</span>`:''}`;
  const gradientControl=(name)=>`<button class="gradient-edit" type="button" data-gradient-edit="${name}" data-gradient-preview="${name}" aria-label="그라디언트 편집"></button>`;
  function gradientValue(part){
    const normalized=window.KMGGradient?.normalize(part||{});
    if(!normalized||normalized.type!=='linear'||!Array.isArray(normalized.stops))return null;
    return normalized;
  }
  function paintGradientControls(){
    if(!window.KMGGradient)return;
    form.querySelectorAll('[data-gradient-preview]').forEach(button=>{
      const part=gradientPart(button.dataset.gradientPreview);
      if(part)button.style.backgroundImage=window.KMGGradient.css(part);
    });
  }
  function gradientPart(name){
    if(name.startsWith('global')){
      const key=name==='globalBackground'?'background':name==='globalFill'?'fill':'stroke';
      return config.globalStyle[key];
    }
    if(name==='regionFill'||name==='regionStroke'){
      if(!selected)return null;
      const key=name==='regionFill'?'fill':'stroke',region=config.regionBackgrounds[selected]||{};
      if(!region[key]){
        region[key]=key==='fill'
          ?{mode:'solid',color:region.color||'#ffffff',color2:region.color2||region.color||'#ffffff',opacity:region.opacity??20,blur:region.blur??16}
          :{mode:region.borderVisible===false?'none':'solid',color:region.borderColor||'#ffffff',color2:region.borderColor2||region.borderColor||'#ffffff',opacity:100,width:4};
        config.regionBackgrounds[selected]=region;
      }
      return region[key];
    }
    return null;
  }
  function openGradient(name,anchor){
    if(name.startsWith('global'))readGlobal();else readEditor();
    const part=gradientPart(name),api=window.KMGGradient;
    if(!part||!api?.open){status.textContent='그라디언트 편집기를 불러오지 못했습니다';return;}
    part.mode='gradient';
    const normalized=gradientValue(part);
    if(!normalized){status.textContent='그라디언트 설정을 읽지 못했습니다';return;}
    part.gradient=normalized;
    const modeName=name==='globalBackground'?'globalBackgroundMode':name==='globalFill'?'globalFillMode':name==='globalStroke'?'globalStrokeMode':name==='regionFill'?'regionFillMode':'regionStrokeMode';
    const gradientRadio=form.querySelector(`input[name="${modeName}"][value="gradient"]`);if(gradientRadio)gradientRadio.checked=true;
    apply();
    api.open(anchor,part,value=>{
      const next=value?.gradient||value;
      const safe=next&&next.type==='linear'&&Array.isArray(next.stops)?next:gradientValue({gradient:next});
      if(!safe)return;
      part.gradient=safe;
      if(safe.stops.length){part.color=safe.stops[0].color;part.color2=safe.stops[safe.stops.length-1].color;}
      if(name==='regionFill'||name==='regionStroke'){
        const colorName=name==='regionFill'?'regionColor':'regionBorderColor',input=control(colorName);
        if(input&&part.color){input.value=part.color;const label=form.querySelector(`[data-color-label="${colorName}"]`);if(label)label.textContent=part.color.toUpperCase();}
      }
      if(name.startsWith('global'))readGlobal();else readEditor();
      paintGradientControls();apply();
    });
  }
  function renderGlobal(){
    const s=config.globalStyle,b=s.background,f=s.fill,t=s.stroke;
    byId('global-settings').innerHTML=`<div class="global-stack">
      <div class="property-section" id="global-background-group"><h4>배경</h4><div class="property-group">
        ${propertyRow('단색',color('globalBackgroundColor',b.color),'globalBackgroundMode','solid',b.mode==='solid')}
        ${propertyRow('그라디언트',gradientControl('globalBackground'),'globalBackgroundMode','gradient',b.mode==='gradient')}
        ${propertyRow('파일',`<label class="mini-action">파일 선택<input data-upload="whole" type="file" accept="image/png,image/jpeg,image/webp,image/gif"></label>`,'globalBackgroundMode','file',b.mode==='file')}
        ${propertyRow('URL',`<input name="globalBackgroundUrl" type="url" placeholder="https://…" value="">`,'globalBackgroundMode','url',b.mode==='url','radio','property-row--long')}
      </div></div><div class="divider"></div>
      <div class="property-section"><h4>패널 채우기</h4><div class="property-group">
        ${propertyRow('없음','','globalFillMode','none',f.mode==='none')}
        ${propertyRow('단색',color('globalFillColor',f.color),'globalFillMode','solid',f.mode==='solid')}
        ${propertyRow('그라디언트',gradientControl('globalFill'),'globalFillMode','gradient',f.mode==='gradient')}
        ${propertyRow('불투명도',num('globalFillOpacity',f.opacity,'%',100))}
        ${propertyRow('흐림',num('globalFillBlur',f.blur,'',64))}
      </div></div><div class="divider"></div>
      <div class="property-section"><h4>패널 테두리</h4><div class="property-group">
        ${propertyRow('없음','','globalStrokeMode','none',t.mode==='none')}
        ${propertyRow('단색',color('globalStrokeColor',t.color),'globalStrokeMode','solid',t.mode==='solid')}
        ${propertyRow('그라디언트',gradientControl('globalStroke'),'globalStrokeMode','gradient',t.mode==='gradient')}
        ${propertyRow('불투명도',num('globalStrokeOpacity',t.opacity,'%',100))}
        ${propertyRow('두께',num('globalStrokeWidth',t.width,'px',32))}
      </div></div></div>`;
    control('globalBackgroundUrl').value=b.url||'';
    paintGradientControls();
  }
  function renderPlacement(){
    byId('placement-list').innerHTML=keys.map(key=>{
      const p=config.panelPlacement[key],fields=['level1','level2'];
      return `<div class="placement-row" data-placement="${key}"><label class="placement-heading"><input type="checkbox" data-enabled="${key}"${config.panelEnabled[key]?' checked':''}><span>${names[key]}</span></label><div class="placement-fields">${fields.map(level=>{const options=level==='level2'&&p.level1==='left'?levelOptions.level2.filter(([value])=>value!=='center'):levelOptions[level],label=level==='level1'?'상위 프레임':'하위 프레임';return `<label class="form-field">${label}<select data-placement-level="${level}" data-panel="${key}">${optionHtml(options,p[level])}</select></label>`;}).join('')}</div></div>`;
    }).join('');
  }
  function updatePlacement(input){
    if(!input.matches('[data-placement-level]'))return false;
    const key=input.dataset.panel,level=input.dataset.placementLevel;
    if(!config.panelPlacement[key])return false;
    const placement=structuredClone(config.panelPlacement);
    placement[key][level]=input.value;
    config.panelPlacement=OverlayEvents.normalizePlacement(placement,level==='level2'?key:undefined);
    renderPlacement();
    return true;
  }
  const editorRow=(label,controlHtml,variant='')=>propertyRow(label,controlHtml,'',undefined,false,'radio',variant);
  const editorColor=(label,name,value)=>editorRow(label,color(name,value));
  const editorNumber=(label,name,value,unit,max)=>editorRow(label,num(name,value,unit,max));
  const fieldHtml=(label,name,type='text',extra='',wide=false)=>editorRow(label,`<input name="${name}" type="${type}" ${extra}>`,wide?'property-row--long':'');
  const urlField=(label,name)=>fieldHtml(label,name,'url','placeholder="https://…" autocomplete="off"',true);
  const editorSelect=(label,name,options,value)=>editorRow(label,`<select name="${name}">${optionHtml(options,value)}</select>`);
  const editorFile=(label,kind,accept)=>editorRow(label,`<label class="mini-action">파일 선택<input data-upload="${kind}" type="file" accept="${accept}"></label>`);
  const editorToggle=(label,name,checked)=>propertyRow(label,'',name,undefined,checked,'checkbox','property-row--toggle');
  function renderEditor(){
    byId('panel-empty').hidden=!!selected;byId('panel-editor').hidden=!selected;
    if(!selected){byId('panel-editor').replaceChildren();return;}
    const key=selected,region=config.regionBackgrounds[key]||{},role=config.slotContent[key]||'none';
    const kinds=[['sponsor','홍보 프리셋'],['alerts','후원 알림 프리셋'],['image','이미지 · GIF'],['video','동영상'],['browser','웹 위젯 URL'],['source','기존 OBS 소스'],['none','비우기']];
    const section=(title,html)=>`<div class="property-section"><h4>${title}</h4><div class="property-group">${html}</div></div>`;
    let content='';
    if(key==='game')content=section('콘텐츠','<p class="editor-help">게임 캡처는 OBS 스크립트에서 기존 게임 소스를 선택하세요.</p>');
    else if(key.startsWith('custom')){
      content=section('콘텐츠',`${editorSelect('표시할 소스','slotRole',kinds,role)}<div id="slot-extra" class="property-group"></div>`);
    }else if(key==='chat')content=section('콘텐츠',urlField('위플랩 채팅 URL','chatUrl'));
    else if(key==='translation')content=section('콘텐츠',urlField('Speech Translator 스트리밍 URL','translationUrl'));
    else if(key==='hand')content=section('콘텐츠',`${editorSelect('오른쪽 아래 소스','cameraMode',[['none','사용 안 함'],['camera','캠'],['reactive','Discord Reactive']],config.cameraMode)}<div id="camera-extra" class="property-group"></div>`);
    const fill=region.fill||{mode:'solid',color:region.color||'#ffffff',opacity:region.opacity??20,blur:region.blur??16};
    const stroke=region.stroke||{mode:region.borderVisible===false?'none':'solid',color:region.borderColor||'#ffffff',opacity:100,width:4};
    const useRegionOverride=!!config.regionStyleOverrides[key];
    const regionInputs=section('영역 스타일',`
      ${editorToggle('전역 설정 대신 개별 설정','regionOverride',config.regionStyleOverrides[key])}
      <div class="property-group region-style-details"${useRegionOverride?'':' hidden'}>
      ${propertyRow('없음','','regionFillMode','none',fill.mode==='none')}
      ${propertyRow('단색',color('regionColor',fill.color||region.color||'#ffffff'),'regionFillMode','solid',fill.mode!=='none'&&fill.mode!=='gradient')}
      ${propertyRow('그라디언트',gradientControl('regionFill'),'regionFillMode','gradient',fill.mode==='gradient')}
      ${editorNumber('불투명도','regionOpacity',region.opacity??20,'%',100)}
      ${editorNumber('블러','regionBlur',region.blur??16,'',64)}
      ${propertyRow('없음','','regionStrokeMode','none',stroke.mode==='none')}
      ${propertyRow('단색',color('regionBorderColor',stroke.color||region.borderColor||'#ffffff'),'regionStrokeMode','solid',stroke.mode!=='none'&&stroke.mode!=='gradient')}
      ${propertyRow('그라디언트',gradientControl('regionStroke'),'regionStrokeMode','gradient',stroke.mode==='gradient')}
      ${editorNumber('테두리 불투명도','regionStrokeOpacity',stroke.opacity??100,'%',100)}
      ${editorNumber('테두리 두께','regionStrokeWidth',stroke.width??4,'px',32)}
      ${fieldHtml('이미지 경로 또는 URL','regionImage','text','placeholder="assets/image.png 또는 https://…"',true)}
      ${editorFile('이미지 파일','region','image/png,image/jpeg,image/webp,image/gif')}
      </div>`);
    byId('panel-editor').innerHTML=`<h4 class="editor-title">${names[key]}</h4>${content}<div class="divider"></div>${regionInputs}`;
    for(const [name,value] of Object.entries({regionColor:fill.color||region.color||'#ffffff',regionOpacity:fill.opacity??region.opacity??20,regionBlur:fill.blur??region.blur??16,regionBorderColor:stroke.color||region.borderColor||'#ffffff',regionStrokeOpacity:stroke.opacity??100,regionStrokeWidth:stroke.width??4,regionImage:region.image||'',chatUrl:config.chatUrl||'',translationUrl:config.translationUrl||''})){const input=control(name);if(input)input.value=value;}
    renderContentExtra();
    paintGradientControls();
  }
  function renderContentExtra(){
    if(!selected)return;
    if(selected.startsWith('custom')){
      const key=selected,role=control('slotRole').value,root=byId('slot-extra');
      let html='';
      if(['image','video','browser'].includes(role))html=urlField('경로 또는 URL','slotUrl');
      if(['image','video'].includes(role))html+=editorFile('파일','slot','image/png,image/jpeg,image/webp,image/gif,video/mp4,video/webm');
      if(role==='source')html='<p class="editor-help">OBS 스크립트에서 이 칸에 넣을 기존 소스를 선택하세요.</p>';
      if(role==='sponsor')html=`${editorSelect('홍보 형식','sponsorType',[['image','이미지 · GIF'],['video','무음 반복 영상'],['embed','웹 위젯']],config.sponsorType||'image')}${urlField('홍보 경로 또는 URL','sponsor')}${editorFile('홍보 파일','sponsor','image/png,image/jpeg,image/webp,image/gif,video/mp4,video/webm')}`;
      if(role==='alerts')html=['Chzzk','Twitch','Youtube','Soop'].map(p=>urlField(p+' 후원 URL','donation'+p)).join('')+'<p class="editor-help">동시 알림은 같은 칸에서 겹칠 수 있습니다.</p>';
      root.innerHTML=html;
      for(const name of ['slotUrl','sponsor','donationChzzk','donationTwitch','donationYoutube','donationSoop']){const input=control(name);if(input)input.value=name==='slotUrl'?config.customSlotMedia[key]?.url||'':config[name]||'';}
    }
    if(selected==='hand'){
      const mode=control('cameraMode').value;
      byId('camera-extra').innerHTML=mode==='reactive'?urlField('Discord Reactive OBS URL','reactiveUrl'):mode==='camera'?`<div class="property-group camera-preview-controls"><label class="form-field">카메라 장치<select name="cameraDevice" aria-label="카메라 장치"></select></label><div class="camera-preview-actions"><button class="mini-action" type="button" data-camera-action="refresh">카메라 새로고침</button><button class="mini-action" type="button" data-camera-action="connect">카메라 연결</button><button class="mini-action" type="button" data-camera-action="disconnect">연결 해제</button></div><p class="editor-help camera-preview-status" role="status"></p><p class="editor-help">실제 OBS 캠은 OBS 스크립트에서 기존 캠 소스를 선택하세요.</p></div>`:'';
      if(control('reactiveUrl'))control('reactiveUrl').value=config.reactiveUrl||'';
      if(mode==='camera')renderCameraControls();
    }
  }
  function cameraStatusText(){
    if(cameraState.errorName&&cameraState.status==='connected')return '카메라 전환에 실패했습니다. 기존 연결을 유지합니다.';
    return ({idle:'카메라를 선택한 뒤 연결하세요.',loading:'카메라 목록 또는 연결 상태를 확인하는 중입니다.',connected:'카메라가 연결되었습니다.',empty:'카메라를 찾을 수 없습니다. 권한 요청을 위해 연결을 눌러 보세요.',denied:'카메라 권한이 거부되었습니다. 브라우저 권한을 확인하세요.',busy:'카메라가 다른 앱에서 사용 중입니다.',unavailable:'이 환경에서는 카메라를 사용할 수 없습니다.',error:'카메라 연결에 실패했습니다.'})[cameraState.status]||'카메라 연결 상태를 확인할 수 없습니다.';
  }
  function renderCameraControls(){
    const root=byId('camera-extra'),group=root?.querySelector('.camera-preview-controls');
    if(!group)return;
    const select=group.querySelector('[name="cameraDevice"]'),previous=select?.value;
    const preferredId=cameraState.status==='connected'&&cameraState.selectedDeviceId?cameraState.selectedDeviceId:previous;
    const selectedId=cameraState.devices.some(device=>device.deviceId===preferredId)?preferredId:(cameraState.selectedDeviceId||'');
    const options=cameraState.devices.length?cameraState.devices.map(device=>`<option value="${escapeHtml(device.deviceId)}"${device.deviceId===selectedId?' selected':''}>${escapeHtml(window.KMGI18n?.localize(device.label)||device.label)}</option>`).join(''):`<option value="">${cameraState.status==='empty'?'카메라 장치가 없습니다':'카메라 장치 확인 중'}</option>`;
    group.querySelector('label').innerHTML=`카메라 장치<select name="cameraDevice" aria-label="카메라 장치">${options}</select>`;
    const status=group.querySelector('.camera-preview-status');if(status)status.textContent=window.KMGI18n?.localize(cameraStatusText())||cameraStatusText();
    const loading=cameraState.status==='loading';
    for(const button of group.querySelectorAll('[data-camera-action]'))button.disabled=loading||(!cameraController&&button.dataset.cameraAction!=='disconnect')||(button.dataset.cameraAction==='disconnect'&&cameraState.status!=='connected');
  }
  function escapeHtml(value){return String(value).replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));}
  function updateCameraOverlay(layout=config.layout){
    const box=layout?.hand,visible=!!(cameraActive&&cameraVideo?.srcObject&&config.cameraMode==='camera'&&config.panelEnabled.hand&&box);
    if(!cameraVideo)return;
    cameraVideo.hidden=!visible;
    if(visible){cameraVideo.style.left=`${box.x/1920*100}%`;cameraVideo.style.top=`${box.y/1080*100}%`;cameraVideo.style.width=`${box.width/1920*100}%`;cameraVideo.style.height=`${box.height/1080*100}%`;}
  }
  function syncCamera(){
    const shouldConnect=config.cameraMode==='camera'&&config.panelEnabled.hand;
    if(shouldConnect&&!cameraActive){cameraActive=true;void cameraController?.refresh();}
    else if(!shouldConnect&&cameraActive){cameraActive=false;cameraController?.disconnect();}
    updateCameraOverlay();
  }
  cameraController=window.KMGCameraPreview?.create({
    onState:state=>{cameraState=state;renderCameraControls();},
    onStream:stream=>{if(cameraVideo){cameraVideo.srcObject=stream||null;if(stream)cameraVideo.play?.().catch(()=>{});else cameraVideo.hidden=true;}updateCameraOverlay();}
  })||null;
  window.addEventListener('pagehide',()=>{cameraActive=false;cameraController?.disconnect();},{once:true});
  function readEditor(){
    if(!selected)return;
    const key=selected,r=config.regionBackgrounds[key]||{},fill=r.fill||{},stroke=r.stroke||{};
    const fillMode=control('regionFillMode')?.value||fill.mode||'solid',strokeMode=control('regionStrokeMode')?.value||stroke.mode||(r.borderVisible===false?'none':'solid');
    r.color=fillMode==='gradient'&&fill.gradient?.stops?.length?fill.gradient.stops[0].color:control('regionColor').value;
    r.opacity=Number(control('regionOpacity').value);r.blur=Number(control('regionBlur').value);
    r.borderColor=strokeMode==='gradient'&&stroke.gradient?.stops?.length?stroke.gradient.stops[0].color:control('regionBorderColor').value;
    r.borderVisible=strokeMode!=='none';r.image=control('regionImage').value.trim();
    Object.assign(fill,{mode:fillMode,color:r.color,color2:fill.color2||r.color,opacity:r.opacity,blur:r.blur});
    Object.assign(stroke,{mode:strokeMode,color:r.borderColor,color2:stroke.color2||r.borderColor,opacity:Number(control('regionStrokeOpacity').value),width:Number(control('regionStrokeWidth').value)});
    r.fill=fill;r.stroke=stroke;
    config.regionBackgrounds[key]=r;config.regionStyleOverrides[key]=control('regionOverride').checked;
    if(key.startsWith('custom')){
      config.slotContent[key]=control('slotRole').value;
      if(control('slotUrl'))config.customSlotMedia[key]={url:control('slotUrl').value.trim()};
      if(control('sponsor')){config.sponsor=control('sponsor').value.trim();config.sponsorType=control('sponsorType').value;}
      for(const name of ['donationChzzk','donationTwitch','donationYoutube','donationSoop'])if(control(name))config[name]=control(name).value.trim();
    }
    if(key==='chat')config.chatUrl=control('chatUrl').value.trim();
    if(key==='translation')config.translationUrl=control('translationUrl').value.trim();
    if(key==='hand'){config.cameraMode=control('cameraMode').value;if(control('reactiveUrl'))config.reactiveUrl=control('reactiveUrl').value.trim();}
  }
  function readGlobal(){
    const b=config.globalStyle.background,f=config.globalStyle.fill,t=config.globalStyle.stroke;
    for(const [part,fields] of [[b,['Mode','Color','Color2','Url']],[f,['Mode','Color','Color2','Opacity','Blur']],[t,['Mode','Color','Color2','Opacity','Width']]]){
      const prefix=part===b?'globalBackground':part===f?'globalFill':'globalStroke';
      for(const suffix of fields){const input=control(prefix+suffix);if(!input)continue;const prop=suffix.toLowerCase()==='color2'?'color2':suffix.toLowerCase();part[prop]=input.type==='number'?Number(input.value):input.value;}
    }
    config.backgroundColor=b.color;config.backgroundImage=['file','url'].includes(b.mode)?b.url:'';
  }
  function liveConfig(source){
    const live=structuredClone(source);
    for(const [key,entry] of uploads){
      if(key==='whole'&&live.backgroundImage===entry.path){live.backgroundImage=entry.url;live.globalStyle.background.url=entry.url;}
      else if(key==='sponsor'&&live.sponsor===entry.path)live.sponsor=entry.url;
      else if(key.startsWith('region-')){const panel=key.slice(7);if(live.regionBackgrounds[panel]?.image===entry.path)live.regionBackgrounds[panel].image=entry.url;}
      else if(live.customSlotMedia[key]?.url===entry.path)live.customSlotMedia[key].url=entry.url;
    }
    return live;
  }
  function savedConfig(source){
    const saved=structuredClone(source);
    for(const [key,entry] of uploads){
      if(key==='whole'&&saved.backgroundImage===entry.path){saved.backgroundImage='';saved.globalStyle.background.url='';saved.globalStyle.background.mode='solid';}
      else if(key==='sponsor'&&saved.sponsor===entry.path)saved.sponsor='';
      else if(key.startsWith('region-')){const panel=key.slice(7);if(saved.regionBackgrounds[panel]?.image===entry.path)saved.regionBackgrounds[panel].image='';}
      else if(saved.customSlotMedia[key]?.url===entry.path){saved.customSlotMedia[key].url='';saved.slotContent[key]='none';}
    }
    return saved;
  }
  function current(){
    readEditor();readGlobal();
    config.layout=OverlayEvents.autoLayout({placement:config.panelPlacement,enabled:config.panelEnabled});
    config.handcam=config.cameraMode==='camera';
    config.showSponsor=Object.values(config.slotContent).includes('sponsor');
    config.showAlerts=Object.values(config.slotContent).includes('alerts');
    return structuredClone(config);
  }
  function drawHits(layout){
    updateCameraOverlay(layout);
    byId('panel-hit-areas').innerHTML=keys.filter(key=>config.panelEnabled[key]).map(key=>{
      const b=layout[key];return `<button class="panel-hit" type="button" data-hit="${key}" aria-label="${names[key]} 설정" aria-pressed="${selected===key}" style="left:${b.x/1920*100}%;top:${b.y/1080*100}%;width:${b.width/1920*100}%;height:${b.height/1080*100}%"></button>`;
    }).join('');
  }
  function apply(message){
    try{
      const data=current(),live=liveConfig(data);
      syncCamera();
      OverlayEvents.resolveSlots(data.slotContent);
      drawHits(data.layout);
      send(frame,'apply',live);
      try{localStorage.setItem('obs-overlay-config',JSON.stringify(savedConfig(data)));localStorage.setItem('obs-overlay-source-config',sourceFingerprint);}catch{}
      status.textContent=message||'설정 미리보기 준비 완료';
    }catch(error){status.textContent=window.KMGI18n?.localize(error.message)||error.message;}
  }
  function selectPanel(key){if(!keys.includes(key)||!config.panelEnabled[key])return;readEditor();selected=selected===key?null:key;renderEditor();syncCamera();drawHits(config.layout||OverlayEvents.autoLayout({placement:config.panelPlacement,enabled:config.panelEnabled}));}
  function reset(){uploadRequests.clear();uploads.clear();cameraActive=false;cameraController?.disconnect();config=normalize(defaults);selected=null;renderGlobal();renderPlacement();renderEditor();apply('기본 설정을 복원했습니다');}

  form.addEventListener('input',event=>{
    const input=event.target;
    if(input.matches('[data-enabled]')){
      const key=input.dataset.enabled;
      if(!input.checked&&selected===key){readEditor();selected=null;renderEditor();}
      config.panelEnabled[key]=input.checked;
    }
    if(input.matches('[data-placement-level]'))return;
    if(input.matches('input[type=color]')){const label=form.querySelector(`[data-color-label="${input.name}"]`);if(label)label.textContent=input.value.toUpperCase();}
    apply();
    paintGradientControls();
  });
  form.addEventListener('change',event=>{
    const input=event.target;
    if(input.matches('[data-upload]')){handleUpload(input);return;}
    if(input.name==='cameraDevice')return;
    if(input.matches('[data-placement-level]')){updatePlacement(input);apply();return;}
    if(input.name==='regionOverride'){
      const details=byId('panel-editor').querySelector('.region-style-details');
      if(details)details.hidden=!input.checked;
    }
    if(input.name==='slotRole'||input.name==='cameraMode'){readEditor();renderContentExtra();}
    apply();
    paintGradientControls();
    if(['globalBackgroundMode','globalFillMode','globalStrokeMode','regionFillMode','regionStrokeMode'].includes(input.name)&&input.value==='gradient'){
      const name=input.name==='globalBackgroundMode'?'globalBackground':input.name==='globalFillMode'?'globalFill':input.name==='globalStrokeMode'?'globalStroke':input.name==='regionFillMode'?'regionFill':'regionStroke';
      const anchor=form.querySelector(`[data-gradient-edit="${name}"]`);if(anchor)openGradient(name,anchor);
    }
  });
  form.addEventListener('click',event=>{const cameraButton=event.target.closest('[data-camera-action]');if(cameraButton){event.preventDefault();if(cameraButton.dataset.cameraAction==='refresh')void cameraController?.refresh();else if(cameraButton.dataset.cameraAction==='connect')void cameraController?.connect(control('cameraDevice')?.value||'');else if(cameraButton.dataset.cameraAction==='disconnect')cameraController?.disconnect();return;}const button=event.target.closest('[data-gradient-edit]');if(button){event.preventDefault();openGradient(button.dataset.gradientEdit,button);}});
  form.addEventListener('submit',event=>event.preventDefault());
  byId('panel-hit-areas').addEventListener('click',event=>{const button=event.target.closest('[data-hit]');if(button)selectPanel(button.dataset.hit);});
  byId('reset').onclick=reset;
  byId('send').onclick=()=>{const type=byId('event-type').value;send(frame,'receive',{type,platform:type==='subtitle'?'external':byId('event-platform').value,nickname:byId('event-name').value,text:byId('event-text').value});status.textContent='테스트 내용을 표시했습니다';};
  const lines=["Let's hold this angle and wait for them to push.",'I heard footsteps on the left.','Thanks for watching!'];
  function sampleStep(){const platform=['chzzk','twitch','youtube','soop'][sampleCount%4];send(frame,'receive',{platform,id:'sample-'+sampleCount,type:'chat',nickname:['한국팬','OverseasFan','Viewer','SOOPViewer'][sampleCount%4],text:['오늘도 응원합니다!','Nice aim!','What sensitivity do you use?','캠 보기 좋아요'][sampleCount%4]});if(sampleCount%2===0)send(frame,'receive',{platform:'external',type:'subtitle',text:lines[(sampleCount/2)%3|0]});sampleCount++;}
  const play=byId('play');
  function stop(){clearInterval(replay);replay=null;play.setAttribute('aria-pressed','false');play.querySelector('[data-play-label]').textContent='샘플 재생';}
  play.onclick=()=>{if(replay){stop();status.textContent='샘플 일시정지';return;}sampleStep();replay=setInterval(sampleStep,2400);play.setAttribute('aria-pressed','true');play.querySelector('[data-play-label]').textContent='일시정지';status.textContent='샘플 재생 중 · 실제 연동 없음';};
  byId('clear').onclick=()=>{stop();send(frame,'clear');status.textContent='화면을 비웠습니다';};

  function previewData(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(reader.error);reader.readAsDataURL(file);});}
  async function readUpload(key,file){
    const ticket={};uploadRequests.set(key,ticket);
    try{
      const url=await previewData(file);
      return uploadRequests.get(key)===ticket?url:null;
    }catch{
      if(uploadRequests.get(key)===ticket){const message='파일을 읽지 못했습니다. 파일을 다시 선택하세요.';status.textContent=window.KMGI18n?.localize(message)||message;}
      return null;
    }
  }
  async function handleUpload(input){
    const file=input.files?.[0];if(!file)return;
    const ext=file.name.split('.').pop().toLowerCase(),video=['mp4','webm'].includes(ext);
    if(!['png','jpg','jpeg','webp','gif','mp4','webm'].includes(ext))return void(status.textContent='지원하지 않는 파일 형식입니다');
    if(video&&['whole','region'].includes(input.dataset.upload))return void(status.textContent='배경에는 이미지를 선택하세요');
    const kind=input.dataset.upload,panelKey=selected;
    if(['slot','region'].includes(kind)&&!panelKey)return;
    const key=kind==='slot'?panelKey:kind==='region'?'region-'+panelKey:kind;
    const path=kind==='whole'?'assets/background-whole.'+ext:kind==='region'?'assets/background-'+panelKey+'.'+ext:kind==='sponsor'?'assets/team-promo.'+ext:'assets/'+panelKey+'.'+ext;
    const url=await readUpload(key,file);if(url===null)return;
    uploads.set(key,{file,path,url});
    if(kind==='whole'){config.globalStyle.background.mode='file';config.globalStyle.background.url=path;renderGlobal();}
    else if(kind==='region'){config.regionBackgrounds[panelKey].image=path;if(selected===panelKey&&control('regionImage'))control('regionImage').value=path;}
    else if(kind==='sponsor'){config.sponsor=path;config.sponsorType=video?'video':'image';if(selected===panelKey)renderContentExtra();}
    else {config.slotContent[panelKey]=video?'video':'image';config.customSlotMedia[panelKey]={url:path};if(selected===panelKey){if(control('slotRole'))control('slotRole').value=config.slotContent[panelKey];renderContentExtra();}}
    apply();
  }
  async function alphaMask(box,name){
    const canvas=document.createElement('canvas');canvas.width=1920;canvas.height=1080;const context=canvas.getContext('2d');
    const {x,y,width,height}=box,r=Math.min(16,width/2,height/2);context.fillStyle='#fff';context.beginPath();context.roundRect(x,y,width,height,r);context.fill();
    const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw new Error('마스크 생성 실패');
    return {name,bytes:new Uint8Array(await blob.arrayBuffer())};
  }
  byId('bundle').onclick=async()=>{
    try{
      const data=current(),uploadSnapshot=Array.from(uploads,([key,entry])=>[key,{...entry}]),entries=OverlayPack.settingsEntries(data);
      for(const [key,name] of [['game','game'],['hand','camera'],['custom1','custom1'],['custom2','custom2'],['custom3','custom3']])entries.push(await alphaMask(data.layout[key],'assets/'+name+'-alpha-mask.png'));
      for(const [key,entry] of uploadSnapshot){const selectedPath=key==='whole'?data.backgroundImage:key==='sponsor'?data.sponsor:key.startsWith('region-')?data.regionBackgrounds[key.slice(7)]?.image:data.customSlotMedia[key]?.url;if(selectedPath===entry.path)entries.push({name:entry.path,bytes:new Uint8Array(await entry.file.arrayBuffer())});}
      const blob=new Blob([OverlayPack.zip(entries)],{type:'application/zip'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='OBS-settings.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);status.textContent='설정 ZIP을 오버레이 폴더에 풀고 OBS에서 자동 배치 적용을 누르세요';
    }catch(error){status.textContent=window.KMGI18n?.localize(error.message)||error.message;}
  };
  frame.addEventListener('load',()=>send(frame,'apply',liveConfig(current())));
  let saved,savedSource;try{saved=JSON.parse(localStorage.getItem('obs-overlay-config'));savedSource=localStorage.getItem('obs-overlay-source-config');}catch{}
  config=normalize(restoredSettings(sourceConfig,saved,savedSource));
  renderGlobal();renderPlacement();renderEditor();apply();
})();
