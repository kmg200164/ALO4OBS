KMG's Streaming Template v0.2.4 — 패키지 안내 / Package guide
변경 기록 / Release notes: CHANGELOG.md

한국어
설정과 OBS 연결 방법은 guide.html에서 확인하세요.
설정 화면은 preview.html입니다. 두 파일 모두 이 폴더에서 열 수 있습니다.
가변 패널 이름은 커스텀 1–3이며 기본 배치는 화면 하단입니다.
위치는 상위 프레임과 하위 프레임으로 지정합니다.

English
Read guide-en.html for configuration and OBS setup.
The settings page is preview.html. Both files are in this folder.
The variable panels are labeled Custom 1–3 and appear along the bottom by default. Their positions use Parent Frame and Child Frame.

日本語
設定とOBSへの接続方法はguide-ja.htmlをご覧ください。
可変パネルはカスタム1～3と表示され、初期配置では画面下部にあります。
位置は親フレームと子フレームで指定します。


Your exported OBS-settings.zip contains personal links and settings. Keep it private.

This delivery is a private gift bundle, not a public-cleared release.
Asset sources and unresolved redistribution permissions: assets/asset-sources.md.
Inter font license: assets/Inter-LICENSE.txt. Identified Lucide icon notice: assets/Lucide-LICENSE.txt.
No project-wide source-code license has been selected.

Windows: extract the full ZIP before opening preview.html or adding obs-setup.lua in OBS.
macOS: extract the full ZIP in Finder, then open preview.html in a browser and add obs-setup.lua in OBS.
The original Source folder and this delivery use the same HTML entry points; internal/ files stay in place.
Always extract OBS-settings.zip into the folder containing obs-setup.lua and replace matching files.
Camera preview requires a browser context that supports camera access. Device choices in the browser
do not select an OBS camera source. macOS browser/OBS device permissions and source availability
have not been tested on this release.
