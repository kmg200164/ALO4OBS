# Asset provenance and public-release blockers

Reviewed 2026-10-04. This inventory records evidence, not a grant of rights.
`build.py` still builds the private gift bundle. Its allowlist is not a public asset clearance list.
No project-wide source-code license has been selected.

Inline SVG icons in `header.js` and `preview.html` also require origin and license review.
Where they duplicate or derive from the SVG files below, the same unresolved rights and notice
requirements apply. Embedding the shapes in HTML/JavaScript does not clear redistribution rights;
the standalone-file inventory must not be treated as the entire icon inventory.

| File | Available provenance | Public redistribution status |
| --- | --- | --- |
| InterVariable.woff2 | Inter; local Inter-LICENSE.txt contains SIL Open Font License 1.1. [Official Inter project](https://rsms.me/inter/) links the license. | License permits bundling with its notice. Exact download/version/hash provenance has not been recorded. |
| Inter-LICENSE.txt | Inter copyright and complete OFL 1.1 text. | Required alongside the font. |
| Lucide-LICENSE.txt | Local ISC notice; [official Lucide license](https://lucide.dev/license). | Covers identified Lucide icons only. Does not establish the origin of every Figma-exported icon. Feather-derived icons require the additional MIT notice listed by Lucide. |
| header-accent.svg | Local Lucide notice identifies the palette icon. | ISC notice present; no upstream version/hash recorded. |
| header-github.svg | UI icon; upstream creator/license not recorded. | Blocked pending origin and permission. |
| header-guide.svg | UI icon; upstream creator/license not recorded. | Blocked pending origin and permission. |
| header-language.svg | UI icon; upstream creator/license not recorded. | Blocked pending origin and permission. |
| header-theme.svg | UI icon; upstream creator/license not recorded. | Blocked pending origin and permission. |
| header-background.svg | UI icon; upstream creator/license not recorded. | Blocked pending origin and permission. |
| header-moon-figma.svg | Figma export; export tool does not establish creator or license. | Blocked pending upstream origin and required notices. |
| header-square-figma.svg | Figma export; export tool does not establish creator or license. | Blocked pending upstream origin and required notices. |
| header-settings-figma.svg | Figma export; export tool does not establish creator or license. | Blocked pending upstream origin and required notices. |
| action-play.svg | Figma export in project records; upstream origin not recorded. | Blocked pending origin and permission. |
| action-clear.svg | Figma export in project records; upstream origin not recorded. | Blocked pending origin and permission. |
| action-example.svg | Figma export in project records; upstream origin not recorded. | Blocked pending origin and permission. |
| action-apply.svg | Figma export in project records; upstream origin not recorded. | Blocked pending origin and permission; currently retained in gift bundle. |
| action-reset.svg | Figma export in project records; upstream origin not recorded. | Blocked pending origin and permission. |
| action-save.svg | Figma export in project records; upstream origin not recorded. | Blocked pending origin and permission. |
| chzzk.png | Official favicon URL in platform-sources.md. | Download location is known; public redistribution permission not established. |
| twitch.png | Official favicon URL in platform-sources.md. [Twitch brand policies](https://legal.twitch.com/en/legal/trademark/) are separate from a software license. | Exact favicon redistribution and proposed usage not cleared. |
| youtube.png | Official favicon URL in platform-sources.md. [YouTube brand resources](https://brand.youtube/) provide usage rules. | Exact favicon redistribution and proposed usage not cleared. |
| soop.ico | Official favicon URL in platform-sources.md. | Download location is known; public redistribution permission not established. |
| season-11-lobby.png | User-supplied THE FINALS season lobby artwork. [Official creator-kit page](https://www.reachthefinals.com/content-creators) does not identify or license this exact local file. | Blocked pending file-specific public redistribution permission. |
| team-tgm25.jpg | Records describe supplied placeholder promotion artwork. Direct inspection shows a game character and game branding, not a team roster or proof of team-issued artwork. | Blocked pending the exact creator/rights-holder and redistribution permission. |
| tgm26-logo.png | User-supplied tournament logo; rights grant absent. | Blocked pending rights-holder permission. |
| tgm26-qualified-banner.png | Derived tournament qualification card using supplied artwork; direct inspection shows tournament/game marks and a qualification caption. | Blocked; authoring a card does not clear embedded artwork or marks. |
| sample-handcam-topview.png | Optional hand-camera still; source creator/permission absent. | Blocked pending origin and permission. |
| sample-mission-widget.png | Static mockup described in project records as inspired by a provider's goal widget. Source creator/license absent. | Blocked pending origin, contained marks/artwork, and permission review. |
| neutral-logo.svg | Neutral vector sample added during project implementation; no third-party source recorded. | Project author must confirm ownership and choose the project license. |
| demo-player.svg | Neutral vector sample added during project implementation; no third-party source recorded. | Project author must confirm ownership and choose the project license. |
| frame.svg | Legacy tracked frame asset; not in gift allowlist. | Ownership/license not recorded; exclude from a future public selection until cleared. |
| game-mask.png | Legacy tracked mask asset; not in gift allowlist. | Origin/license not recorded; exclude from a future public selection until cleared. |
| hand-mask.png | Legacy tracked mask asset; not in gift allowlist. | Origin/license not recorded; exclude from a future public selection until cleared. |
| GameCapture-Corner.png | Legacy tracked corner graphic; not in gift allowlist. | Origin/license not recorded; exclude from a future public selection until cleared. |

Future README screenshots must be reviewed for personal names, widget URLs, account details,
and embedded third-party artwork. Generated `*-alpha-mask.png` files belong to personal settings
exports and are not delivery assets.

Local `background-whole.jpg` is an uploaded personal background, excluded from the gift allowlist.
Local `game-alpha-mask.png` and `camera-alpha-mask.png` are generated settings-export masks,
also excluded. They must not be copied into a public file selection by directory globbing.

Public preparation must choose a separate asset selection and remove or replace every blocked
dependency from its HTML, CSS, JavaScript, examples, and documentation. Do not silently remove
files from the user's working folder or rewrite Git history to achieve that selection.
