// Neutral defaults packaged as config.js. Keep personal settings in the local config.js only.
window.OVERLAY_PUBLIC_CONFIG = window.OVERLAY_CONFIG = {
  layoutVersion: 2,
  name: "PLAYER", accent: "#ad92ff", panel: "#1a1a1a", text: "#ffffff",
  logo: "assets/neutral-logo.svg", sponsor: "", sponsorType: "image",
  showSponsor: true, showSubtitles: true, showChat: true, showAlerts: true,
  handcam: false, showNicknames: true, nicknameColor: "platform",
  cameraMode: "none", reactiveUrl: "",
  slotContent: {custom1: "sponsor", custom2: "alerts", custom3: "none"},
  customSlotMedia: {custom1: {url: ""}, custom2: {url: ""}, custom3: {url: ""}},
  backgroundColor: "#000000", backgroundImage: "",
  regionBackgrounds: Object.fromEntries(["game", "custom1", "custom2", "custom3", "chat", "translation", "hand"].map(key => [key, {
    color: "#ffffff", image: "", opacity: 20, blur: 16,
    borderColor: "#ffffff", borderVisible: true
  }])),
  platforms: ["chzzk", "twitch", "youtube", "soop"], alertDuration: 7000,
  chatUrl: "", translationUrl: "",
  donationChzzk: "", donationTwitch: "", donationYoutube: "", donationSoop: ""
};
