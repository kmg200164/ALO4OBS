window.KMG_VERSION = '0.6.0';
